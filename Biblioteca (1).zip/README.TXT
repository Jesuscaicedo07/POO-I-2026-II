Biblioteca - MVC (Modelo, Vista, Controlador). Ejecutar Main.
