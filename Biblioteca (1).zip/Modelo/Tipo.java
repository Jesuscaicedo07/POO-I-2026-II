package Modelo;

public enum Tipo
{
    REFERENCIA, COLECCION
}
