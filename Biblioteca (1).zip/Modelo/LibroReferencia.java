package Modelo;

public class LibroReferencia extends Libro
{
    // Un libro de referencia solo tiene dos copias
    public LibroReferencia(String titulo, Autor autor, String issn, String anioPublicacion, String editorial){
        super(titulo, autor, Tipo.REFERENCIA, issn, anioPublicacion, editorial, 2);
    }
}
