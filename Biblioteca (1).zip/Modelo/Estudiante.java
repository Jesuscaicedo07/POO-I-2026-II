package Modelo;

public class Estudiante extends Usuario
{
    private int numSemestre;
    private int creditos;

    public Estudiante(){}

    public Estudiante(String id, String nombre, String correo, String telefono, int numSemestre, int creditos){
        super(id, nombre, correo, telefono);
        this.numSemestre=numSemestre;
        this.creditos=creditos;
    }

    public int getPlazoMaximo(){ return 15; }
    public String getTipo(){ return "Estudiante"; }

    public int getNumSemestre(){ return this.numSemestre; }
    public void setNumSemestre(int numSemestre){ this.numSemestre = numSemestre; }

    public int getCreditos(){ return this.creditos; }
    public void setCreditos(int creditos){ this.creditos = creditos; }
}
