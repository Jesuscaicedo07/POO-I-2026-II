package Modelo;

public abstract class Usuario
{
    protected String nombre;
    protected String id;
    protected String correo;
    protected String telefono;

    public Usuario(){}

    public Usuario(String id, String nombre, String correo, String telefono){
        this.id=id;
        this.nombre=nombre;
        this.correo=correo;
        this.telefono=telefono;
    }

    // Plazo maximo de prestamo en dias (lo define cada tipo de usuario)
    public abstract int getPlazoMaximo();

    public abstract String getTipo();

    public String getNombre(){ return this.nombre; }
    public void setNombre(String nombre){ this.nombre = nombre; }

    public String getId(){ return this.id; }
    public void setId(String id){ this.id = id; }

    public String getCorreo(){ return this.correo; }
    public void setCorreo(String correo){ this.correo = correo; }

    public String getTelefono(){ return this.telefono; }
    public void setTelefono(String telefono){ this.telefono = telefono; }

    public String toString(){
        return id + " - " + nombre + " (" + getTipo() + ")";
    }
}
