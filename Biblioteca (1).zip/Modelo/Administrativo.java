package Modelo;

public class Administrativo extends Usuario
{
    private String departamento;
    private String jefe;

    public Administrativo(){}

    public Administrativo(String id, String nombre, String correo, String telefono, String departamento, String jefe){
        super(id, nombre, correo, telefono);
        this.departamento=departamento;
        this.jefe=jefe;
    }

    public int getPlazoMaximo(){ return 3; }
    public String getTipo(){ return "Administrativo"; }

    public String getDepartamento(){ return this.departamento; }
    public void setDepartamento(String departamento){ this.departamento = departamento; }

    public String getJefe(){ return this.jefe; }
    public void setJefe(String jefe){ this.jefe = jefe; }
}
