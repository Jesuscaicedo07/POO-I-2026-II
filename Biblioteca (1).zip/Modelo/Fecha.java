package Modelo;

import java.time.LocalDate;

public class Fecha
{
    private int dia;
    private int mes;
    private int anio;

    public Fecha(){}

    public Fecha(int dia, int mes, int anio){
        this.dia=dia;
        this.mes=mes;
        this.anio=anio;
    }

    public Fecha(LocalDate f){
        this(f.getDayOfMonth(), f.getMonthValue(), f.getYear());
    }

    public LocalDate toLocalDate(){
        return LocalDate.of(anio, mes, dia);
    }

    public int getDia(){ return this.dia; }
    public void setDia(int dia){ this.dia=dia; }

    public int getMes(){ return this.mes; }
    public void setMes(int mes){ this.mes=mes; }

    public int getAnio(){ return this.anio; }
    public void setAnio(int anio){ this.anio=anio; }

    public String toString(){
        return toLocalDate().toString();    // aaaa-mm-dd
    }
}
