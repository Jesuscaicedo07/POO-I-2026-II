package Modelo;

import java.util.ArrayList;
import java.util.List;

public abstract class Libro
{
    private String titulo;
    private Autor autor;
    private Tipo tipo;
    private String issn;
    private String anioPublicacion;
    private String editorial;
    private Prestamo prestamo;
    private int numeroCopias;           // copias en total
    private int copiasDisponibles;
    private List<Autor> autores;

    public Libro(){}

    public Libro(String titulo, Autor autor, Tipo tipo, String issn, String anioPublicacion, String editorial, int numeroCopias){
        this.titulo=titulo;
        this.autor=autor;
        this.tipo=tipo;
        this.issn=issn;
        this.anioPublicacion=anioPublicacion;
        this.editorial=editorial;
        this.numeroCopias=numeroCopias;
        this.copiasDisponibles=numeroCopias;
        this.autores= new ArrayList<>();
    }

    // Presta una copia si hay disponibles
    public boolean prestarCopia(){
        if(copiasDisponibles > 0){
            copiasDisponibles--;
            return true;
        }
        return false;
    }

    public void devolverCopia(){
        if(copiasDisponibles < numeroCopias){
            copiasDisponibles++;
        }
    }

    public void agregarAutor(Autor autor){
        this.autores.add(autor);
    }

    public String getTitulo(){ return this.titulo; }
    public void setTitulo(String titulo){ this.titulo = titulo; }

    public Autor getAutor(){ return this.autor; }
    public void setAutor(Autor autor){ this.autor = autor; }

    public Tipo getTipo(){ return this.tipo; }
    public void setTipo(Tipo tipo){ this.tipo = tipo; }

    public String getIssn(){ return this.issn; }
    public void setIssn(String issn){ this.issn = issn; }

    public String getAnioPublicacion(){ return this.anioPublicacion; }
    public void setAnioPublicacion(String anioPublicacion){ this.anioPublicacion = anioPublicacion; }

    public String getEditorial(){ return this.editorial; }
    public void setEditorial(String editorial){ this.editorial = editorial; }

    public Prestamo getPrestamo(){ return this.prestamo; }
    public void setPrestamo(Prestamo prestamo){ this.prestamo = prestamo; }

    public int getNumeroCopias(){ return this.numeroCopias; }
    public void setNumeroCopias(int numeroCopias){ this.numeroCopias = numeroCopias; }

    public int getCopiasDisponibles(){ return this.copiasDisponibles; }

    public String toString(){
        return titulo + " (" + tipo + ")";
    }
}
