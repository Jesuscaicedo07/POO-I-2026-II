package Modelo;

public class Profesor extends Usuario
{
    private String materia;
    private int aniosExp;

    public Profesor(){}

    public Profesor(String id, String nombre, String correo, String telefono, String materia, int aniosExp){
        super(id, nombre, correo, telefono);
        this.materia=materia;
        this.aniosExp=aniosExp;
    }

    public int getPlazoMaximo(){ return 15; }
    public String getTipo(){ return "Profesor"; }

    public String getMateria(){ return this.materia; }
    public void setMateria(String materia){ this.materia = materia; }

    public int getAniosExp(){ return this.aniosExp; }
    public void setAniosExp(int aniosExp){ this.aniosExp = aniosExp; }
}
