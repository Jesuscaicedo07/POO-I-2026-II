package Modelo;

import java.time.LocalDate;

public class Prestamo
{
    private String codigo;
    private Fecha fechaPrestada;
    private Fecha fechaDevuelta;     // null mientras no se haya devuelto el libro
    private Usuario usuario;
    private Libro libro;
    private Estado estado;

    public Prestamo(){}

    public Prestamo(String codigo, Usuario usuario, Libro libro, Fecha fechaPrestada){
        this.codigo=codigo;
        this.usuario=usuario;
        this.libro=libro;
        this.fechaPrestada=fechaPrestada;
        this.estado=Estado.PRESTADO;
    }

    // Fecha limite segun el plazo del tipo de usuario
    public Fecha getFechaLimite(){
        return new Fecha(fechaPrestada.toLocalDate().plusDays(usuario.getPlazoMaximo()));
    }

    public boolean estaActivo(){
        return fechaDevuelta == null;
    }

    // Se multa el prestamo cuando pasa el tiempo limite de devolucion
    public void actualizarEstado(LocalDate hoy){
        if(estaActivo() && hoy.isAfter(getFechaLimite().toLocalDate())){
            estado = Estado.MULTADO;
        }
    }

    public boolean devolver(LocalDate fecha){
        if(!estaActivo() || fecha.isBefore(fechaPrestada.toLocalDate())){
            return false;
        }
        fechaDevuelta = new Fecha(fecha);
        libro.devolverCopia();
        estado = fecha.isAfter(getFechaLimite().toLocalDate()) ? Estado.MULTADO : Estado.DEVUELTO;
        return true;
    }

    public String getCodigo(){ return this.codigo; }
    public void setCodigo(String codigo){ this.codigo = codigo; }

    public Fecha getFechaPrestada(){ return this.fechaPrestada; }
    public void setFechaPrestada(Fecha fechaPrestada){ this.fechaPrestada = fechaPrestada; }

    public Fecha getFechaDevuelta(){ return this.fechaDevuelta; }
    public void setFechaDevuelta(Fecha fechaDevuelta){ this.fechaDevuelta = fechaDevuelta; }

    public Usuario getUsuario(){ return this.usuario; }
    public void setUsuario(Usuario usuario){ this.usuario = usuario; }

    public Libro getLibro(){ return this.libro; }
    public void setLibro(Libro libro){ this.libro = libro; }

    public Estado getEstado(){ return this.estado; }
    public void setEstado(Estado estado){ this.estado = estado; }

    public String toString(){
        return codigo + " - " + usuario.getNombre() + " - " + libro.getTitulo() + " [" + estado + "]";
    }
}
