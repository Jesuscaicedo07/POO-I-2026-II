package Modelo;

public enum Estado
{
    PRESTADO, DEVUELTO, MULTADO
}
