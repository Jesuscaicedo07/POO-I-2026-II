package vista;
import javax.swing.*;
import java.awt.*;
import modelo.Cardenal;
import java.util.ArrayList;
import java.util.List; 
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;


/**
 * Write a description of class JFConclave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class JFConclave extends JFrame implements ActionListener{
    
    JLabel lblLista, lblRonda; 
    JButton btnVotar, btnMostrar, btnSiguiente;
    JComboBox <String> cmbLista;
    JTextArea txtEsp;
    JTextField txtRonda;
    JTable tabla;
    private DefaultTableModel modelo; 
    
    private ArrayList<Cardenal> listaCandidatos;
    private ArrayList<Integer> contadorVotosCandidatos;
    private int totalVotosGlobal;
    
    public JFConclave (ArrayList<Cardenal> listaCandidatos){
        
         this.listaCandidatos = listaCandidatos;
        this.contadorVotosCandidatos = new ArrayList<>();
        this.totalVotosGlobal = 0;

        setTitle ("Votaciones conclave");
        setSize (700,700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        
        JPanel listados1 = new JPanel (new GridLayout (2,2,5,5));
        
        JPanel lista = new JPanel (new GridLayout (1,2,5,5));
        
        JPanel lista1 = new JPanel (new GridLayout (1,1,5,5));
        lblLista = new JLabel ("Lista de Cardenales");
        
        JPanel lista2 = new JPanel (new GridLayout (1,1,5,5));
        cmbLista = new JComboBox <>(); 
       
        for (Cardenal c : listaCandidatos) {
            cmbLista.addItem(c.getNombre());
            contadorVotosCandidatos.add(0);
        }
        
        JPanel botones = new JPanel(new GridLayout (1,2,5,5));
        
        JPanel boton1 = new JPanel(new GridLayout (1,1,5,5));
        boton1.setLayout(new BoxLayout(boton1,BoxLayout.X_AXIS));
        btnVotar = new JButton("Votar");
        
        
        JPanel ronda = new JPanel(new GridLayout (1,2,5,5));
        
        JPanel ronda1= new JPanel (new GridLayout (1,1,5,5));
        lblRonda = new JLabel ("Ronda Num");
        
        JPanel ronda2= new JPanel (new GridLayout (1,1,5,5));
        txtRonda = new JTextField ("1");
        txtRonda.setEditable(false); 
        
        JPanel listados2 = new JPanel (new GridLayout (2,1,5,5));
        
        JPanel mostrar = new JPanel(new GridLayout(1, 2, 10, 0)); 
        
         JPanel panelTabla = new JPanel(new BorderLayout());
        String[] columnas = {"Nombre", "Votos"};
        modelo = new DefaultTableModel(columnas, 0);
        tabla = new JTable(modelo);
        JScrollPane scrollTabla = new JScrollPane(tabla); // Envolver en scroll para ver cabeceras
        
        
        JPanel panelTexto = new JPanel(new BorderLayout());
        txtEsp = new JTextArea();
        txtEsp.setEditable(false); // Recomendado para que el usuario no digite encima
        JScrollPane scrollTexto = new JScrollPane(txtEsp); // Opcional pero recomendado por si el texto es largo
        
        
        JPanel botones22 = new JPanel(new GridLayout (1,2,5,5));
        boton1.setLayout(new BoxLayout(boton1,BoxLayout.X_AXIS));
        btnMostrar = new JButton("Mostrar Resultados");
        btnSiguiente = new JButton("Siguiente Ronda");
        
        lista.add(lista1);
        lista.add(lista2);
        botones.add(boton1);
        botones.add(ronda);
        lista1.add(lblLista, BorderLayout.WEST);
        lista2.add(cmbLista, BorderLayout.EAST);
        boton1.add(btnVotar, BorderLayout.CENTER);
        ronda.add(ronda1);
        ronda.add(ronda2);
        ronda1.add(lblRonda,BorderLayout.WEST); 
        ronda2.add(txtRonda,BorderLayout.EAST); 
        panelTabla.add(scrollTabla, BorderLayout.CENTER);
        panelTexto.add(scrollTexto, BorderLayout.CENTER);
        botones22.add(btnMostrar);
        botones22.add(btnSiguiente);
        listados1.add(lista, BorderLayout.NORTH);
        listados1.add(botones, BorderLayout.SOUTH);
        mostrar.add(panelTabla,BorderLayout.WEST);
        mostrar.add(panelTexto,BorderLayout.EAST);
        listados2.add(botones22, BorderLayout.SOUTH);
        add(listados1, BorderLayout.NORTH);
        add(mostrar,BorderLayout.CENTER);
        add(listados2, BorderLayout.SOUTH);
        
        
        btnVotar.addActionListener(this);
        btnMostrar.addActionListener(this);
        btnSiguiente.addActionListener(this);


        
        setVisible (true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnVotar) {
            int indiceSeleccionado = cmbLista.getSelectedIndex();
            if (indiceSeleccionado != -1) {
                
                Cardenal seleccionado = listaCandidatos.get(indiceSeleccionado);
                seleccionado.registrarVoto(); 
                totalVotosGlobal++;
                
                mostrarEscrutinioActual("=== ESCRUTINIO EN TIEMPO REAL ===");
            }
            
        } else if (e.getSource() == btnMostrar) {
            if (totalVotosGlobal == 0) {
                txtEsp.setText("Aún no se han registrado votos en esta ronda.\n");
                return;
            }
            mostrarEscrutinioActual("=== RESULTADOS PARCIALES ===");
            
        } else if (e.getSource() == btnSiguiente) {
            int rondaActual = Integer.parseInt(txtRonda.getText());
            txtRonda.setText(String.valueOf(rondaActual + 1));
            
            
            totalVotosGlobal = 0;
            
            for (Cardenal c : listaCandidatos) {
                c.reiniciarVotos(); 
                modelo.setRowCount(0); 
            }
            
            btnVotar.setEnabled(true);
            txtEsp.setText("=== RONDA " + (rondaActual + 1) + " INICIADA ===\n");
            txtEsp.append("Se han quemado las papeletas antiguas. Inicie la nueva votación.\n");
        }
    }

    private void mostrarEscrutinioActual(String encabezado) {
        double votosRequeridos = (totalVotosGlobal * 2.0) / 3.0;
        modelo.setRowCount(0); 
        txtEsp.setText(encabezado + "\n");
        txtEsp.append("Total de votos en esta ronda: " + totalVotosGlobal + "\n");
        txtEsp.append("Votos para ganar (2/3): " + String.format("%.2f", votosRequeridos) + "\n\n");
        txtEsp.append("Votos actuales:\n");
        
        Cardenal ganador = null;
        for (Cardenal c : listaCandidatos) {
            
             modelo.addRow(new Object[]{c.getNombre(), c.getVotos()});
            txtEsp.append("- " + c.getNombre() + ": " + c.getVotos() + " votos\n");
            
            if (c.getVotos() >= votosRequeridos) {
                ganador = c;
            }
        }
        
        if (ganador != null) {
            txtEsp.append("\n HUMO BLANCO \n");
            txtEsp.append("\n¡HABEMUS PAPAM!\n");
            txtEsp.append("El cardenal: " + ganador.getNombre() + " es el nuevo Papa con " + ganador.getVotos() + " votos.");
             
        } else {
            txtEsp.append("\nHumo Negro: Ningún candidato alcanza los 2/3 requeridos.");
        }
    }
    
}