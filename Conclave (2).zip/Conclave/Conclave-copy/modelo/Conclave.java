package modelo;
import java.util.ArrayList;
import java.util.List; 
import vista.JFConclave;
/**
 * Write a description of class Conclave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Conclave {
    public static void main(String[] args) {
        // Declarar e inicializar el ArrayList de Cardenales
        ArrayList<Cardenal> listaCandidatos = new ArrayList<>();

        // Añadir candidatos respetando el nuevo constructor: (Tipo, Pais, Nombre, Edad, Enfermo)
        listaCandidatos.add(new Cardenal(TipoCardenal.OBISPO, Pais.FILIPINAS, "Cardenal Luis Antonio Tagle", 69, false));
        listaCandidatos.add(new Cardenal(TipoCardenal.OBISPO, Pais.COLOMBIA, "Cardenal Luis José Rueda", 64, false));
        listaCandidatos.add(new Cardenal(TipoCardenal.OBISPO, Pais.FRANCIA, "Cardenal Robert Sarah", 81, false)); 
        listaCandidatos.add(new Cardenal(TipoCardenal.OBISPO, Pais.KENIA, "Cardenal John Njue", 80, true));       
        listaCandidatos.add(new Cardenal(TipoCardenal.OBISPO, Pais.UCRANIA, "Cardenal Mykola Bychok", 46, false));

        listaCandidatos.removeIf(c -> c.getEdad() >= 81 || c.isEnfermo());
  
        JFConclave ventana = new JFConclave(listaCandidatos);
        
    
       
        ventana.setVisible(true);
    }
}