package modelo;
import javax.swing.*;
import modelo.Conclave;
import vista.JFConclave;
/**
 * Write a description of class Cardenales here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cardenal
{
    private TipoCardenal tipoCardenal;
    private Pais pais;
    private String nombre;
    private int edad;
    private boolean enfermo=false;
    private int votos;
    
    public Cardenal(){}
    
    public Cardenal(TipoCardenal tipoCardenal, Pais pais, String nombre, int edad, boolean enfermo){
        this.tipoCardenal = tipoCardenal;
        this.pais = pais;
        this.nombre = nombre;
        this.edad = edad;
        this.enfermo = enfermo;
        this.votos = 0;
    }

//Start GetterSetterExtension Source Code
    public void registrarVoto() {
        this.votos++;
    }

    /** Obtiene la cantidad de votos actuales */
    public int getVotos() {
        return this.votos;
    }

    /** Reinicia los votos a 0 para una nueva ronda */
    public void reiniciarVotos() {
        this.votos = 0;
    }

    /**GET Method Propertie tipoCardenal*/
    public TipoCardenal getTipoCardenal(){
        return this.tipoCardenal;
    }//end method getTipoCardenal

    /**SET Method Propertie tipoCardenal*/
    public void setTipoCardenal(TipoCardenal tipoCardenal){
        this.tipoCardenal = tipoCardenal;
    }//end method setTipoCardenal

    /**GET Method Propertie pais*/
    public Pais getPais(){
        return this.pais;
    }//end method getPais

    /**SET Method Propertie pais*/
    public void setPais(Pais pais){
        this.pais = pais;
    }//end method setPais
    
    public String getNombre() {
        return this.nombre;
    }
    
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    /**GET Method Propertie edad*/
    public int getEdad(){
        return this.edad;
    }//end method getEdad

    /**SET Method Propertie edad*/
    public void setEdad(int edad){
        this.edad = edad;
    }//end method setEdad
   
    public boolean isEnfermo() {
        return this.enfermo;
    }
//End GetterSetterExtension Source Code
   
   

  
   
}

