package modelo;


/**
 * Write a description of class Colegio here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Colegio
{
    private Cardenal cardenal;
}