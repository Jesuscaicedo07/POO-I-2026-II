
/**
 * Write a description of class JFCalculador here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

 import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Locale;

public class JFCalculador extends JFrame implements ActionListener
{
    // Lista de vehículos y posición del que se muestra
    private ArrayList<Calculador> vehiculos;
    private int posicion;

    private JLabel labelConImagen2;
    private JLabel lblMarca, lblLinea, lblModelo, lblValor;
    private JButton btn1, btn2, btn3, btn4, btnBLinea, btnBMarca, btnBCaro, btnCalcular, btnOp1, btnOp2;
    private JTextField txtMarca, txtLinea, txtModelo, txtValor, txtBLinea, txtBMarca;
    private JCheckBox chkProntoPago, chkServicioPublico, chkTrasladoCuenta;

    public JFCalculador(){
        cargarVehiculos();
        posicion = 0;

        setTitle("Cálculo Impuestos");
        setSize(800, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        crearInterfaz();
        mostrarVehiculo();
        setVisible(true);
    }

    private void cargarVehiculos(){
        vehiculos = new ArrayList<Calculador>();
        vehiculos.add(new Calculador("Ford", "Taurus", "2016", 136340000, "fotoc.png"));
        vehiculos.add(new Calculador("Mazda", "3", "2018", 65000000, "fotoc.png"));
        vehiculos.add(new Calculador("Peugeot", "206", "2012", 18000000, "fotoc.png"));
        vehiculos.add(new Calculador("Peugeot", "307", "2014", 28000000, "fotoc.png"));
        vehiculos.add(new Calculador("Chevrolet", "Spark", "2017", 10000000, "fotoc.png"));
        vehiculos.add(new Calculador("Renault", "Duster", "2019", 72000000, "fotoc.png"));
        vehiculos.add(new Calculador("Mercedes-Benz", "C200", "2020", 230000000, "fotoc.png"));
    }

    public void crearInterfaz(){
        JPanel principal = new JPanel();
        principal.setLayout(new BoxLayout(principal, BoxLayout.Y_AXIS));
        principal.setBorder(new EmptyBorder(10, 15, 10, 15));

        // ---------- Zona 1: encabezado ----------
        JPanel encabezado = new JPanel(new BorderLayout());
        ImageIcon icono = new ImageIcon("images/fotop.png");
        JLabel labelConImagen1 = new JLabel(icono);
        encabezado.add(labelConImagen1, BorderLayout.CENTER);

        // ---------- Zona 2: datos del vehículo ----------
        JPanel datos = new JPanel();
        datos.setLayout(new BorderLayout(15, 0));
        datos.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY), "Datos del vehiculo", 0, 0, new Font("Tahoma", Font.BOLD, 12), Color.BLUE),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        labelConImagen2 = new JLabel("", SwingConstants.CENTER);
        labelConImagen2.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        labelConImagen2.setPreferredSize(new Dimension(220, 140));
        labelConImagen2.setMinimumSize(new Dimension(220, 140));
        labelConImagen2.setMaximumSize(new Dimension(220, 140));

        JPanel etiquetas = new JPanel(new GridLayout(4, 1, 0, 10));
        lblMarca = new JLabel("marca");
        lblMarca.setFont(new Font("Tahoma", Font.BOLD, 11));
        lblLinea = new JLabel("linea");
        lblLinea.setFont(new Font("Tahoma", Font.BOLD, 11));
        lblModelo = new JLabel("modelo");
        lblModelo.setFont(new Font("Tahoma", Font.BOLD, 11));
        lblValor = new JLabel("valor");
        lblValor.setFont(new Font("Tahoma", Font.BOLD, 11));

        JPanel texto = new JPanel(new GridLayout(4, 1, 0, 10));
        texto.setPreferredSize(new Dimension(180, 140));

        txtMarca = new JTextField("");
        txtMarca.setFont(new Font("Tahoma", Font.BOLD, 11));
        txtMarca.setEditable(false);
        txtLinea = new JTextField("");
        txtLinea.setFont(new Font("Tahoma", Font.BOLD, 11));
        txtLinea.setEditable(false);
        txtModelo = new JTextField("");
        txtModelo.setFont(new Font("Tahoma", Font.BOLD, 11));
        txtModelo.setEditable(false);
        txtValor = new JTextField("");
        txtValor.setFont(new Font("Tahoma", Font.BOLD, 11));
        txtValor.setEditable(false);

        JPanel mover = new JPanel(new GridLayout(1, 4, 0, 10));
        btn1 = new JButton("<<");
        btn2 = new JButton("<");
        btn3 = new JButton(">");
        btn4 = new JButton(">>");

        // ---------- Zona 3: búsquedas ----------
        JPanel busqueda = new JPanel();
        busqueda.setLayout(new GridLayout(1, 2, 10, 10));
        busqueda.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY), "Busquedas", 0, 0, new Font("Tahoma", Font.BOLD, 12), Color.BLUE),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        JPanel espacio = new JPanel(new GridLayout(3, 1, 0, 10));
        txtBLinea = new JTextField("");
        txtBLinea.setFont(new Font("Tahoma", Font.BOLD, 11));
        txtBMarca = new JTextField("");
        txtBMarca.setFont(new Font("Tahoma", Font.BOLD, 11));

        JPanel botones = new JPanel(new GridLayout(3, 1, 0, 10));
        btnBLinea = new JButton("Buscar Por linea");
        btnBMarca = new JButton("Buscar por marca");
        btnBCaro = new JButton("Buscar vehiculo mas caro");

        // ---------- Zona 4: descuentos ----------
        JPanel descuentos = new JPanel(new GridLayout(2, 2, 10, 5));
        descuentos.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY), "Descuentos", 0, 0, new Font("Tahoma", Font.BOLD, 12), Color.BLUE),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        chkProntoPago = new JCheckBox("Pronto pago");
        chkProntoPago.setFont(new Font("Tahoma", Font.BOLD, 11));
        chkServicioPublico = new JCheckBox("Servicio público");
        chkServicioPublico.setFont(new Font("Tahoma", Font.BOLD, 11));
        chkTrasladoCuenta = new JCheckBox("Traslado de cuenta");
        chkTrasladoCuenta.setFont(new Font("Tahoma", Font.BOLD, 11));

        // ---------- Zona 5: opciones ----------
        JPanel opciones = new JPanel(new GridLayout(1, 3, 10, 0));
        opciones.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY), "Opciones", 0, 0, new Font("Tahoma", Font.BOLD, 12), Color.BLUE),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        btnCalcular = new JButton("Calcular");
        btnOp1 = new JButton("Opcion 1");
        btnOp2 = new JButton("Opcion 2");

        // ---------- Agregar componentes a sus paneles ----------
        etiquetas.add(lblMarca);
        etiquetas.add(lblLinea);
        etiquetas.add(lblModelo);
        etiquetas.add(lblValor);

        texto.add(txtMarca);
        texto.add(txtLinea);
        texto.add(txtModelo);
        texto.add(txtValor);

        mover.add(btn1);
        mover.add(btn2);
        mover.add(btn3);
        mover.add(btn4);

        datos.add(labelConImagen2, BorderLayout.WEST);
        datos.add(etiquetas, BorderLayout.CENTER);
        datos.add(texto, BorderLayout.EAST);
        datos.add(mover, BorderLayout.SOUTH);

        espacio.add(txtBLinea);
        espacio.add(txtBMarca);
        espacio.add(new JLabel(""));      // la tercera fila queda vacía

        botones.add(btnBLinea);
        botones.add(btnBMarca);
        botones.add(btnBCaro);

        busqueda.add(espacio);
        busqueda.add(botones);

        descuentos.add(chkProntoPago);
        descuentos.add(chkTrasladoCuenta);
        descuentos.add(chkServicioPublico);

        opciones.add(btnCalcular);
        opciones.add(btnOp1);
        opciones.add(btnOp2);

        // ---------- Armar la ventana ----------
        fijarAlto(encabezado);
        fijarAlto(datos);
        fijarAlto(busqueda);
        fijarAlto(descuentos);
        fijarAlto(opciones);

        principal.add(encabezado);
        principal.add(Box.createVerticalStrut(10));
        principal.add(datos);
        principal.add(Box.createVerticalStrut(10));
        principal.add(busqueda);
        principal.add(Box.createVerticalStrut(10));
        principal.add(descuentos);
        principal.add(Box.createVerticalStrut(10));
        principal.add(opciones);
        add(principal);

        // ---------- Escuchar los botones ----------
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        btn4.addActionListener(this);
        btnBLinea.addActionListener(this);
        btnBMarca.addActionListener(this);
        btnBCaro.addActionListener(this);
        btnCalcular.addActionListener(this);
        btnOp1.addActionListener(this);
        btnOp2.addActionListener(this);
    }

    /** Evita que BoxLayout estire el panel hacia abajo. */
    private void fijarAlto(JPanel p){
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, p.getPreferredSize().height));
    }

    private void mostrarVehiculo(){
        Calculador v = vehiculos.get(posicion);
        txtMarca.setText(v.getMarca());
        txtLinea.setText(v.getLinea());
        txtModelo.setText(v.getModelo());
        txtValor.setText(formatoMoneda(v.getValor()));

        ImageIcon foto = cargarFoto(v.getImagen());
        if (foto == null) {
            foto = cargarFoto("fotoc.png");
        }
        if (foto != null) {
            labelConImagen2.setText("");
            labelConImagen2.setIcon(foto);
        } else {
            labelConImagen2.setIcon(null);
            labelConImagen2.setText("Sin imagen");
        }
    }   // <-- esta llave faltaba en tu archivo

    private ImageIcon cargarFoto(String nombre){
        if (nombre == null || nombre.isEmpty()) return null;
        File f = new File("images/" + nombre);
        if (!f.exists()) return null;
        Image img = new ImageIcon(f.getPath()).getImage()
                .getScaledInstance(218, 138, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }

    private String formatoMoneda(double valor){
        DecimalFormat df = new DecimalFormat("$ #,##0", new DecimalFormatSymbols(Locale.US));
        return df.format(valor);
    }

    // ------------------------------------------------------------------
    // Eventos
    // ------------------------------------------------------------------
    public void actionPerformed(ActionEvent e){
        Object origen = e.getSource();

        if (origen == btn1) {
            posicion = 0;
            mostrarVehiculo();
        } else if (origen == btn2) {
            if (posicion > 0) posicion--;
            mostrarVehiculo();
        } else if (origen == btn3) {
            if (posicion < vehiculos.size() - 1) posicion++;
            mostrarVehiculo();
        } else if (origen == btn4) {
            posicion = vehiculos.size() - 1;
            mostrarVehiculo();
        } else if (origen == btnBLinea) {
            buscarPorLinea();
        } else if (origen == btnBMarca) {
            buscarPorMarca();
        } else if (origen == btnBCaro) {
            buscarMasCaro();
        } else if (origen == btnCalcular) {
            calcular();
        } else if (origen == btnOp1) {
            JOptionPane.showMessageDialog(this, "Respuesta 1");
        } else if (origen == btnOp2) {
            JOptionPane.showMessageDialog(this, "Respuesta 2");
        }
    }

    private void buscarPorLinea(){      // <-- aquí tenías "rivate"
        String texto = txtBLinea.getText().trim();
        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese la línea a buscar.",
                "Búsqueda", JOptionPane.WARNING_MESSAGE);
            return;
        }
        for (int i = 0; i < vehiculos.size(); i++) {
            if (vehiculos.get(i).getLinea().equalsIgnoreCase(texto)) {
                posicion = i;
                mostrarVehiculo();
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No se encontró ningún vehículo con la línea \"" + texto + "\".",
            "Búsqueda", JOptionPane.INFORMATION_MESSAGE);
    }

    private void buscarPorMarca(){
        String texto = txtBMarca.getText().trim();
        if (texto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese la marca a buscar.",
                "Búsqueda", JOptionPane.WARNING_MESSAGE);
            return;
        }
        for (int i = 0; i < vehiculos.size(); i++) {
            if (vehiculos.get(i).getMarca().equalsIgnoreCase(texto)) {
                posicion = i;
                mostrarVehiculo();
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "No se encontró ningún vehículo de la marca \"" + texto + "\".",
            "Búsqueda", JOptionPane.INFORMATION_MESSAGE);
    }

    private void buscarMasCaro(){
        int mayor = 0;
        for (int i = 1; i < vehiculos.size(); i++) {
            if (vehiculos.get(i).getValor() > vehiculos.get(mayor).getValor()) {
                mayor = i;
            }
        }
        posicion = mayor;
        mostrarVehiculo();
    }

    private void calcular(){
        Calculador v = vehiculos.get(posicion);
        double base = v.calcularImpuestos();
        double total = v.calcularTotal(chkProntoPago.isSelected(),
                                       chkServicioPublico.isSelected(),
                                       chkTrasladoCuenta.isSelected());
        String mensaje = "Impuesto sin descuentos: " + formatoMoneda(base)
                       + "\nValor total a pagar: " + formatoMoneda(total);
        JOptionPane.showMessageDialog(this, mensaje, "Impuesto a pagar",
            JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args){
        new JFCalculador();
    }
}

