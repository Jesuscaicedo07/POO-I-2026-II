import java.io.*;
import java.util.*;
import java.util.ArrayList.*;
/**
 * Representa un vehiculo (marca, linea, modelo, valor) y sabe calcular
 * su impuesto anual y los descuentos.
 */
public class Calculador
{
    private String marca;
    private String linea;
    private String modelo;
    private double valor;
    private String imagen;

    // Descuentos
    public static final double PORC_PRONTO_PAGO = 0.10;
    public static final double VALOR_SERVICIO_PUBLICO = 50000;
    public static final double PORC_TRASLADO = 0.05;

    // Tabla de rangos compartida por todos los vehiculos
    private static ArrayList<Rango> rangos = cargarRangos();

    public Calculador(){}

    public Calculador(String marca, String linea, String modelo, double valor, String imagen){
        this.marca = marca;
        this.linea = linea;
        this.modelo = modelo;
        this.valor = valor;
        this.imagen = imagen;
    }

    public String getMarca() { return marca; }
    public void setMarca(String marca) { this.marca = marca; }

    public String getLinea() { return linea; }
    public void setLinea(String linea) { this.linea = linea; }

    public String getModelo() { return modelo; }
    public void setModelo(String modelo) { this.modelo = modelo; }

    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }

    public String getImagen() { return imagen; }
    public void setImagen(String imagen) { this.imagen = imagen; }

    // ------------------------------------------------------------------
    // Tabla de rangos: se lee de rangos.txt (si no existe usa valores por defecto)
    // ------------------------------------------------------------------
    private static ArrayList<Rango> cargarRangos(){
        ArrayList<Rango> lista = new ArrayList<Rango>();
        try (BufferedReader br = new BufferedReader(new FileReader("rangos.txt"))) {
            String fila;
            while ((fila = br.readLine()) != null) {
                fila = fila.trim();
                if (fila.isEmpty() || fila.startsWith("#")) continue;
                String[] p = fila.split(";");
                lista.add(new Rango(Double.parseDouble(p[0].trim()),
                                    Double.parseDouble(p[1].trim())));
            }
        } catch (IOException | NumberFormatException | ArrayIndexOutOfBoundsException e) {
            lista.clear();
        }
        if (lista.isEmpty()) {
            lista.add(new Rango(30000000, 1.5));
            lista.add(new Rango(70000000, 2.0));
            lista.add(new Rango(200000000, 2.5));
            lista.add(new Rango(-1, 4.0));
        }
        Collections.sort(lista);
        return lista;
    }

    // ------------------------------------------------------------------
    // Impuesto
    // ------------------------------------------------------------------

    /** Impuesto anual (sin descuentos) para un valor dado. */
    public double calcularImpuestos(double valor){
        for (Rango r : rangos) {
            if (r.contiene(valor)) {
                return valor * r.getPorcentaje() / 100.0;
            }
        }
        return 0;
    }

    /** Impuesto anual (sin descuentos) de este vehiculo. */
    public double calcularImpuestos(){
        return calcularImpuestos(valor);
    }

    // ------------------------------------------------------------------
    // Descuentos: cada uno recibe el impuesto actual y devuelve el nuevo
    // ------------------------------------------------------------------

    /** Descuento 1: pronto pago (10%). */
    public double descuento1(double impuesto){
        return impuesto - impuesto * PORC_PRONTO_PAGO;
    }

    /** Descuento 2: servicio publico ($50.000), sin dejar el impuesto negativo. */
    public double descuento2(double impuesto){
        double resultado = impuesto - VALOR_SERVICIO_PUBLICO;
        if (resultado < 0) {
            resultado = 0;
        }
        return resultado;
    }

    /** Descuento 3: traslado de registro (5%). */
    public double descuento3(double impuesto){
        return impuesto - impuesto * PORC_TRASLADO;
    }

    /** Aplica los descuentos seleccionados, en el orden 1, 2, 3. */
    public double calcularTotal(boolean prontoPago, boolean servicioPublico, boolean traslado){
        double impuesto = calcularImpuestos();
        if (prontoPago) {
            impuesto = descuento1(impuesto);
        }
        if (servicioPublico) {
            impuesto = descuento2(impuesto);
        }
        if (traslado) {
            impuesto = descuento3(impuesto);
        }
        return impuesto;
    }
}
