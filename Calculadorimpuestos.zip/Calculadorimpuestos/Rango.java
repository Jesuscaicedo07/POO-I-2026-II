public class Rango implements Comparable<Rango>
{
    private double limite;
    private double porcentaje;

    public Rango(double limite, double porcentaje) {
        this.limite = limite;
        this.porcentaje = porcentaje;
    }

    public double getLimite()     { return limite; }
    public double getPorcentaje() { return porcentaje; }

    private double limiteEfectivo() {
        return limite < 0 ? Double.MAX_VALUE : limite;
    }

    /** true si el valor cae dentro de este rango (con los rangos ordenados). */
    public boolean contiene(double valor) {
        return valor <= limiteEfectivo();
    }

    public int compareTo(Rango otro) {
        return Double.compare(limiteEfectivo(), otro.limiteEfectivo());
    }
}
