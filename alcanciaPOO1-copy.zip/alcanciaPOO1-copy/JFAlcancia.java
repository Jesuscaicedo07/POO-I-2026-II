
/**
 * Write a description of class JFAlcancia here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.lang.*;
public class JFAlcancia extends JFrame 
{
    
    private JLabel lblTitulo;
    private JLabel lblSaldo;
    private JLabel lblTotal;
    private JLabel lblTituloMonedas;
    private JButton btn50;
    private JButton btn100;
    private JButton btn200;
    private JButton btn500;
    private JButton btn1000;
    private JLabel lbl50;
    private JLabel lbl100;
    private JLabel lbl200;
    private JLabel lbl500;
    private JLabel lbl1000;
    private JLabel lblTotalMonedas;
    private JButton btnVaciar;
    private Alcancia alcancia;
    private JLabel lbltextoSaldo;
    
    public JFAlcancia(){
        
        alcancia = new Alcancia();
        setTitle("Mi Alcancia - POO I");
        setSize(500,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        
        crearInterfaz();
        actualizarInterfaz();
        setVisible(true);

    }
    
    public void crearInterfaz(){
        JPanel principal = new JPanel();
        principal.setLayout(new BorderLayout(15,15));
        principal.setBorder(new EmptyBorder(20,25,20,25));
        
        //Encabezado -superior
        JPanel encabezado = new JPanel ();
        encabezado.setLayout(new BoxLayout(encabezado,BoxLayout.Y_AXIS));
        
        lblTitulo = new JLabel("MI ALCANCIA");
        lblTitulo.setFont(new Font("Tahoma",Font.BOLD,30));
        lblTitulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        
        ImageIcon icono = new ImageIcon("src/images/cerdo.png");
        JLabel labelConImagen = new JLabel(icono);
        
        lblSaldo = new JLabel("$0");
        lblSaldo.setFont(new Font("Tahoma",Font.BOLD,40));
        lblSaldo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        lbltextoSaldo = new JLabel("Saldo disponible");
        lbltextoSaldo.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        encabezado.add(labelConImagen);
        encabezado.add(lblTitulo);
        encabezado.add(lblSaldo);
        encabezado.add(lbltextoSaldo);
        
        principal.add(encabezado,BorderLayout.NORTH);
        
        //centro
        
        JPanel panelCentro = new JPanel();
        panelCentro.setLayout(new BoxLayout(panelCentro,BoxLayout.Y_AXIS));
        
        lblTituloMonedas= new JLabel("INGRESAR MONEDAS");
        lblTituloMonedas.setFont(new Font("Tahoma",Font.BOLD,20));
        lblTituloMonedas.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        panelCentro.add(lblTituloMonedas);
        
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER,8,12));
         btn50 = new JButton("$50");
         btn100 = new JButton("$100");
         btn200 = new JButton("$200");
         btn500 = new JButton("$500");
         btn1000 = new JButton("$1000");
        
        
        botones.add(btn50);
        botones.add(btn100);
        botones.add(btn200);
        botones.add(btn500);
        botones.add(btn1000);
        
        panelCentro.add(botones);
        
        JPanel panelResumen = new JPanel(new GridLayout(6, 1, 5, 5));
        panelResumen.setBorder(BorderFactory.createTitledBorder("Resumen de la alcancía"));
        
        lbl50 = new JLabel("Monedas de $50:    0");
        lbl100 = new JLabel("Monedas de $100:  0");
        lbl200 = new JLabel("Monedas de $200:  0");
        lbl500 = new JLabel("Monedas de $500:  0");
        lbl1000 = new JLabel("Monedas de $1.000: 0");
        lblTotalMonedas = new JLabel("TOTAL DE MONEDAS: 0"); // Añadido
        
        panelResumen.add(lbl50);
        panelResumen.add(lbl100);
        panelResumen.add(lbl200);
        panelResumen.add(lbl500);
        panelResumen.add(lbl1000);
        panelResumen.add(lblTotalMonedas);
        
        panelCentro.add(Box.createVerticalStrut(15)); // Espaciado estético
        panelCentro.add(panelResumen);
        
        principal.add(panelCentro, BorderLayout.CENTER);
        
        // Zona Inferior - Botón Vaciar Alcancía
        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.CENTER));
        btnVaciar = new JButton("VACIAR ALCANCIA");
        btnVaciar.setFont(new Font("Tahoma", Font.BOLD, 14));
        panelInferior.add(btnVaciar);
        
        principal.add(panelInferior, BorderLayout.SOUTH);
        
        
        this.add(principal);
        btn50.addActionListener(e->agregarMonedas(50));
        btn100.addActionListener(e->agregarMonedas(100));
        btn200.addActionListener(e->agregarMonedas(200));
        btn500.addActionListener(e->agregarMonedas(500));
        btn1000.addActionListener(e->agregarMonedas(1000));
        btnVaciar.addActionListener(e -> vaciar());
        
    }
    
    
    
    private void agregarMonedas(int valor) {
    // 1. Llamas al método de la OTRA clase a través del objeto 'alcancia'
    alcancia.agregarMonedas(valor); 
    
    // 2. Refrescas la pantalla para que muestre el nuevo saldo
    actualizarInterfaz();
}

    
    private void vaciar(){
        alcancia.vaciar();
        actualizarInterfaz();
    }
    
    public void actualizarInterfaz(){
    lblSaldo.setText("$" + alcancia.getSaldo()); 
    
    // 2. Actualizar los contadores de cuántas monedas hay de cada una
    // (Asumiendo que tu clase Alcancia tiene métodos para obtener la cantidad de cada moneda)
    lbl50.setText("Monedas de $50: " + alcancia.getMonedas50());
    lbl100.setText("Monedas de $100: " + alcancia.getMonedas100());
    lbl200.setText("Monedas de $200: " + alcancia.getMonedas200());
    lbl500.setText("Monedas de $500: " + alcancia.getMonedas500());
    lbl1000.setText("Monedas de $1000: " + alcancia.getMonedas1000());
    lblTotalMonedas.setText("TOTAL DE MONEDAS: " + alcancia.getTotalMonedas());
    }

}