package modelo;


/**
 * Distribucion del bono de un Docente: implementos tecnologicos y
 * pago de servicios (luz o internet).
 */
public class Servicios
{
    private double servicios;
    private double implementosTecnologicos;

    public Servicios() {
    }

    public Servicios(double implementosTecnologicos, double servicios) {
        this.implementosTecnologicos = implementosTecnologicos;
        this.servicios = servicios;
    }

    public double getServicios() {
        return servicios;
    }

    public void setServicios(double servicios) {
        this.servicios = servicios;
    }

    public double getImplementosTecnologicos() {
        return implementosTecnologicos;
    }

    public void setImplementosTecnologicos(double implementosTecnologicos) {
        this.implementosTecnologicos = implementosTecnologicos;
    }

    /** Suma de todo lo gastado. */
    public double getTotal() {
        return servicios + implementosTecnologicos;
    }
}
