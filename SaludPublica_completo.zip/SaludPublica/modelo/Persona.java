package modelo;


/**
 * Clase padre de todas las personas que reciben bono (ProfesionalSalud,
 * Docente y Ciudadano). Gracias a la herencia y al polimorfismo, el
 * controlador guarda todas en un ArrayList<Persona>.
 */
public abstract class Persona
{
    protected TipoDocumento tipoDocumento;
    protected Bono bono;
    protected String nombre;
    protected String apellido;
    protected String documento;
    protected String telefono;
    protected String direccion;
    protected int edad;
    protected EstadoCivil estadoCivil;
    protected int sisben;
    protected boolean cabezaHogar;

    public Persona(TipoDocumento tipoDocumento, Bono bono, String nombre, String apellido, String documento,
    String telefono, String direccion, int edad, EstadoCivil estadoCivil, int sisben, boolean cabezaHogar) {
        this.tipoDocumento = tipoDocumento;
        this.bono = bono;
        this.nombre = nombre;
        this.apellido = apellido;
        this.documento = documento;
        this.telefono = telefono;
        this.direccion = direccion;
        this.edad = edad;
        this.estadoCivil = estadoCivil;
        this.sisben = sisben;
        this.cabezaHogar = cabezaHogar;
    }

    // ------------------------------------------------------------------
    // Metodos que cada tipo de persona implementa a su manera (polimorfismo)
    // ------------------------------------------------------------------

    /** Nombre de la clasificacion: Profesional de la Salud, Docente o Ciudadano. */
    public abstract String getClasificacion();

    /** Suma de lo que la persona distribuyo de su bono. */
    public abstract double getTotalDistribuido();

    /** Texto con los datos propios de cada tipo de persona. */
    public abstract String getDatosEspecificos();

    // ------------------------------------------------------------------
    // Metodos comunes
    // ------------------------------------------------------------------

    /** El total distribuido no puede superar el monto del bono asignado. */
    public boolean distribucionValida() {
        return getTotalDistribuido() <= bono.getMonto();
    }

    public double getSaldoBono() {
        return bono.getMonto() - getTotalDistribuido();
    }

    public String getNombreCompleto() {
        return nombre + " " + apellido;
    }

    /** Resumen completo de la persona: datos basicos y datos segun su tipo. */
    public String getResumen() {
        return "Clasificacion: " + getClasificacion() + "\n"
             + "Documento: " + tipoDocumento.getSiglas() + " " + documento + "\n"
             + "Nombre: " + getNombreCompleto() + "\n"
             + "Direccion: " + direccion + "\n"
             + "Telefono: " + telefono + "\n"
             + "Edad: " + edad + "\n"
             + "Estrato (Sisben): " + sisben + "\n"
             + "Estado civil: " + estadoCivil.getEtiqueta() + "\n"
             + "Cabeza de hogar: " + (cabezaHogar ? "Si" : "No") + "\n"
             + getDatosEspecificos() + "\n"
             + "Bono asignado: " + Bono.formatear(bono.getMonto()) + "\n"
             + "Total distribuido: " + Bono.formatear(getTotalDistribuido()) + "\n"
             + "Saldo del bono: " + Bono.formatear(getSaldoBono());
    }

    @Override
    public String toString() {
        return getClasificacion() + " - " + getNombreCompleto() + " (" + documento + ")";
    }

    // ------------------------------------------------------------------
    // Getters y setters
    // ------------------------------------------------------------------

    public TipoDocumento getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(TipoDocumento tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public Bono getBono() {
        return bono;
    }

    public void setBono(Bono bono) {
        this.bono = bono;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public EstadoCivil getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(EstadoCivil estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

    public int getSisben() {
        return sisben;
    }

    public void setSisben(int sisben) {
        this.sisben = sisben;
    }

    public boolean isCabezaHogar() {
        return cabezaHogar;
    }

    public void setCabezaHogar(boolean cabezaHogar) {
        this.cabezaHogar = cabezaHogar;
    }
}
