package modelo;


/**
 * Nivel educativo de un docente. Las etiquetas coinciden con las de la
 * lista desplegable "Nivel" del formulario.
 */
public enum Nivel
{
    PRIMARIA("Primaria"),
    SECUNDARIA("Secundaria"),
    TECNICO("Tecnico"),
    PREGRADO("Pregrado"),
    POSGRADO("Posgrado");

    private final String etiqueta;

    private Nivel(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    /**
     * Busca el nivel a partir de su etiqueta (ej: "Pregrado").
     * Retorna null si no existe.
     */
    public static Nivel desdeEtiqueta(String texto) {
        for (Nivel nivel : values()) {
            if (nivel.etiqueta.equalsIgnoreCase(texto)) {
                return nivel;
            }
        }
        return null;
    }
}
