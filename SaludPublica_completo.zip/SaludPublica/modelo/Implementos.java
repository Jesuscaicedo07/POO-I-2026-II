package modelo;


/**
 * Distribucion del bono de un Profesional de la Salud:
 * elementos de bioseguridad y medicina.
 */
public class Implementos
{
    private double elementosBioseguridad;
    private double medicina;

    public Implementos() {
    }

    public Implementos(double elementosBioseguridad, double medicina) {
        this.elementosBioseguridad = elementosBioseguridad;
        this.medicina = medicina;
    }

    public double getElementosBioseguridad() {
        return elementosBioseguridad;
    }

    public void setElementosBioseguridad(double elementosBioseguridad) {
        this.elementosBioseguridad = elementosBioseguridad;
    }

    public double getMedicina() {
        return medicina;
    }

    public void setMedicina(double medicina) {
        this.medicina = medicina;
    }

    /** Suma de todo lo gastado. */
    public double getTotal() {
        return elementosBioseguridad + medicina;
    }
}
