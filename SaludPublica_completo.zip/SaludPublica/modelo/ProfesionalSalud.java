package modelo;


/**
 * Profesional de la salud: bono de $350.000 que puede redimir en
 * elementos de bioseguridad o medicina.
 */
public class ProfesionalSalud extends Persona
{
    private String institucionSalud;
    private String especialidad;
    private Implementos implementos;

    public ProfesionalSalud(TipoDocumento tipoDocumento, String nombre, String apellido, String documento,
    String telefono, String direccion, int edad, EstadoCivil estadoCivil, int sisben, boolean cabezaHogar,
    String institucionSalud, String especialidad, Implementos implementos) {
        super(tipoDocumento, new Bono(Bono.MONTO_PROFESIONAL_SALUD), nombre, apellido, documento,
              telefono, direccion, edad, estadoCivil, sisben, cabezaHogar);
        this.institucionSalud = institucionSalud;
        this.especialidad = especialidad;
        this.implementos = implementos;
    }

    @Override
    public String getClasificacion() {
        return "Profesional de la Salud";
    }

    @Override
    public double getTotalDistribuido() {
        return implementos.getTotal();
    }

    @Override
    public String getDatosEspecificos() {
        return "Institucion de salud: " + institucionSalud + "\n"
             + "Especialidad: " + especialidad + "\n"
             + "Elementos de bioseguridad: " + Bono.formatear(implementos.getElementosBioseguridad()) + "\n"
             + "Medicina: " + Bono.formatear(implementos.getMedicina());
    }

    public String getInstitucionSalud() {
        return institucionSalud;
    }

    public void setInstitucionSalud(String institucionSalud) {
        this.institucionSalud = institucionSalud;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public Implementos getImplementos() {
        return implementos;
    }

    public void setImplementos(Implementos implementos) {
        this.implementos = implementos;
    }
}
