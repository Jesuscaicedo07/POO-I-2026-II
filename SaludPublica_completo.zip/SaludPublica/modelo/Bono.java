package modelo;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

/**
 * Bono en dinero que entrega el Estado. El monto depende del tipo de persona.
 */
public class Bono
{
    public static final double MONTO_CIUDADANO = 160000;
    public static final double MONTO_PROFESIONAL_SALUD = 350000;
    public static final double MONTO_DOCENTE = 100000;

    private double monto;

    public Bono() {
        this.monto = 0;
    }

    public Bono(double monto) {
        this.monto = monto;
    }

    public double getMonto() {
        return monto;
    }

    public void setMonto(double monto) {
        this.monto = monto;
    }

    /**
     * Da formato de pesos colombianos: 350000 -> $350.000
     */
    public static String formatear(double valor) {
        DecimalFormatSymbols simbolos = new DecimalFormatSymbols();
        simbolos.setGroupingSeparator('.');
        simbolos.setDecimalSeparator(',');
        return new DecimalFormat("$#,##0", simbolos).format(valor);
    }
}
