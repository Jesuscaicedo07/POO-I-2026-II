package modelo;


/**
 * Docente: bono de $100.000 que debe redimir en implementos de tecnologia
 * o en el pago de servicios de luz o internet.
 */
public class Docente extends Persona
{
    private String institucionEducativa;
    private Nivel nivel;
    private Servicios servicios;

    public Docente(TipoDocumento tipoDocumento, String nombre, String apellido, String documento,
    String telefono, String direccion, int edad, EstadoCivil estadoCivil, int sisben, boolean cabezaHogar,
    String institucionEducativa, Nivel nivel, Servicios servicios) {
        super(tipoDocumento, new Bono(Bono.MONTO_DOCENTE), nombre, apellido, documento,
              telefono, direccion, edad, estadoCivil, sisben, cabezaHogar);
        this.institucionEducativa = institucionEducativa;
        this.nivel = nivel;
        this.servicios = servicios;
    }

    @Override
    public String getClasificacion() {
        return "Docente";
    }

    @Override
    public double getTotalDistribuido() {
        return servicios.getTotal();
    }

    @Override
    public String getDatosEspecificos() {
        return "Institucion educativa: " + institucionEducativa + "\n"
             + "Nivel educativo: " + nivel.getEtiqueta() + "\n"
             + "Implementos tecnologicos: " + Bono.formatear(servicios.getImplementosTecnologicos()) + "\n"
             + "Servicio internet/energia: " + Bono.formatear(servicios.getServicios());
    }

    public String getInstitucionEducativa() {
        return institucionEducativa;
    }

    public void setInstitucionEducativa(String institucionEducativa) {
        this.institucionEducativa = institucionEducativa;
    }

    public Nivel getNivel() {
        return nivel;
    }

    public void setNivel(Nivel nivel) {
        this.nivel = nivel;
    }

    public Servicios getServicios() {
        return servicios;
    }

    public void setServicios(Servicios servicios) {
        this.servicios = servicios;
    }
}
