package modelo;


/**
 * Distribucion del bono de un Ciudadano: medicina y canasta familiar.
 */
public class Medicina
{
    private double medicina;
    private double canastaFamiliar;

    public Medicina() {
    }

    public Medicina(double medicina, double canastaFamiliar) {
        this.medicina = medicina;
        this.canastaFamiliar = canastaFamiliar;
    }

    public double getMedicina() {
        return medicina;
    }

    public void setMedicina(double medicina) {
        this.medicina = medicina;
    }

    public double getCanastaFamiliar() {
        return canastaFamiliar;
    }

    public void setCanastaFamiliar(double canastaFamiliar) {
        this.canastaFamiliar = canastaFamiliar;
    }

    /** Suma de todo lo gastado. */
    public double getTotal() {
        return medicina + canastaFamiliar;
    }
}
