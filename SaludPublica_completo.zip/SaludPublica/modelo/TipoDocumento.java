package modelo;


/**
 * Tipos de documento de identidad. Cada uno tiene las siglas que se
 * muestran en la lista desplegable del formulario.
 */
public enum TipoDocumento
{
    REGISTRO_CIVIL("R.C"),
    TARJETA_IDENTIDAD("T.I"),
    CEDULA_CIUDADANIA("C.C"),
    PERMISO_ESPECIAL_PERMANENCIA("P.E.P");

    private final String siglas;

    private TipoDocumento(String siglas) {
        this.siglas = siglas;
    }

    public String getSiglas() {
        return siglas;
    }

    /**
     * Busca el tipo de documento a partir de sus siglas (ej: "C.C").
     * Retorna null si no existe.
     */
    public static TipoDocumento desdeSiglas(String texto) {
        for (TipoDocumento tipo : values()) {
            if (tipo.siglas.equalsIgnoreCase(texto)) {
                return tipo;
            }
        }
        return null;
    }
}
