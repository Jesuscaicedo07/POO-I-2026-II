package modelo;


/**
 * Ciudadano (persona independiente) de estrato Sisben 1 o 2: bono de
 * $160.000 que debe gastar en medicina o productos de la canasta familiar.
 */
public class Ciudadano extends Persona
{
    private Medicina medicina;

    public Ciudadano(TipoDocumento tipoDocumento, String nombre, String apellido, String documento,
    String telefono, String direccion, int edad, EstadoCivil estadoCivil, int sisben, boolean cabezaHogar,
    Medicina medicina) {
        super(tipoDocumento, new Bono(Bono.MONTO_CIUDADANO), nombre, apellido, documento,
              telefono, direccion, edad, estadoCivil, sisben, cabezaHogar);
        this.medicina = medicina;
    }

    @Override
    public String getClasificacion() {
        return "Ciudadano";
    }

    @Override
    public double getTotalDistribuido() {
        return medicina.getTotal();
    }

    @Override
    public String getDatosEspecificos() {
        return "Medicina: " + Bono.formatear(medicina.getMedicina()) + "\n"
             + "Canasta familiar: " + Bono.formatear(medicina.getCanastaFamiliar());
    }

    public Medicina getMedicina() {
        return medicina;
    }

    public void setMedicina(Medicina medicina) {
        this.medicina = medicina;
    }
}
