package modelo;

import java.text.Normalizer;

/**
 * Estados civiles posibles. Como en el formulario el estado civil se
 * escribe en un campo de texto, desdeTexto() lo convierte al enumerado
 * ignorando mayusculas, tildes y la terminacion femenina (soltera, casada...).
 */
public enum EstadoCivil
{
    SOLTERO("Soltero"),
    CASADO("Casado"),
    VIUDO("Viudo"),
    DIVORCIADO("Divorciado"),
    UNION_LIBRE("Union libre");

    private final String etiqueta;

    private EstadoCivil(String etiqueta) {
        this.etiqueta = etiqueta;
    }

    public String getEtiqueta() {
        return etiqueta;
    }

    /**
     * Convierte un texto en un estado civil. Retorna null si no coincide.
     */
    public static EstadoCivil desdeTexto(String texto) {
        if (texto == null) {
            return null;
        }
        String buscado = normalizar(texto);
        EstadoCivil encontrado = buscar(buscado);
        if (encontrado == null && buscado.endsWith("a")) {
            // soltera -> soltero, casada -> casado, viuda -> viudo...
            encontrado = buscar(buscado.substring(0, buscado.length() - 1) + "o");
        }
        return encontrado;
    }

    private static EstadoCivil buscar(String normalizado) {
        for (EstadoCivil estado : values()) {
            if (normalizar(estado.etiqueta).equals(normalizado)) {
                return estado;
            }
        }
        return null;
    }

    private static String normalizar(String texto) {
        String sinTildes = Normalizer.normalize(texto.trim(), Normalizer.Form.NFD)
                                     .replaceAll("\\p{M}", "");
        return sinTildes.toLowerCase().replace('_', ' ');
    }
}
