package controlador;

import modelo.*;
import vista.JFSalud;
import javax.swing.SwingUtilities;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

/**
 * Controlador (capa de control): conecta el formulario (vista) con las
 * clases del modelo. Atiende los botones Guardar, Limpiar y Buscar y la
 * seleccion del tipo de persona.
 *
 * Todas las personas se guardan en un ArrayList de la clase padre (Persona),
 * aprovechando el polimorfismo: ProfesionalSalud, Docente y Ciudadano
 * conviven en la misma lista.
 */
public class ControladorSalud implements ActionListener
{
    private JFSalud vista;
    private ArrayList<Persona> personas;

    /** Crea el formulario y lo conecta con este controlador. */
    public ControladorSalud() {
        this(new JFSalud());
    }

    public ControladorSalud(JFSalud vista) {
        this.vista = vista;
        this.personas = new ArrayList<Persona>();
        this.vista.setControlador(this);
    }

    /** Punto de entrada para ejecutar la aplicacion. */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new ControladorSalud();
            }
        });
    }

    public ArrayList<Persona> getPersonas() {
        return personas;
    }

    // ------------------------------------------------------------------
    // Eventos
    // ------------------------------------------------------------------

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        if (JFSalud.CMD_TIPO.equals(comando)) {
            vista.habilitarSegunTipo(vista.getTipo());
        } else if (JFSalud.CMD_GUARDAR.equals(comando)) {
            guardar();
        } else if (JFSalud.CMD_LIMPIAR.equals(comando)) {
            vista.limpiar();
        } else if (JFSalud.CMD_BUSCAR.equals(comando)) {
            buscar();
        }
    }

    // ------------------------------------------------------------------
    // Guardar
    // ------------------------------------------------------------------

    private void guardar() {
        try {
            Persona persona = crearPersona();
            if (buscarPorDocumento(persona.getDocumento()) != null) {
                throw new IllegalArgumentException(
                    "Ya existe una persona registrada con el documento " + persona.getDocumento() + ".");
            }
            personas.add(persona);
            vista.mostrarMensaje("Registro guardado", "La persona se guardo correctamente.\n\n" + persona.getResumen());
            vista.limpiar();
        } catch (IllegalArgumentException ex) {
            vista.mostrarError(ex.getMessage());
        }
    }

    /**
     * Lee el formulario, valida los datos y construye el objeto que
     * corresponde al tipo seleccionado. Lanza IllegalArgumentException
     * con un mensaje claro si algo no es valido.
     */
    private Persona crearPersona() {
        String tipo = vista.getTipo();
        if (tipo.isEmpty()) {
            throw new IllegalArgumentException("Seleccione el tipo de persona.");
        }

        // --- Datos basicos (comunes a todos los tipos) ---
        TipoDocumento tipoDocumento = TipoDocumento.desdeSiglas(vista.getTipoDocumento());
        if (tipoDocumento == null) {
            throw new IllegalArgumentException("Seleccione el tipo de documento.");
        }
        String documento = soloDigitos(vista.getDocumento(), "Documento");
        String nombre = textoObligatorio(vista.getNombre(), "Nombre");
        String apellido = textoObligatorio(vista.getApellido(), "Apellido");
        String direccion = textoObligatorio(vista.getDireccion(), "Direccion");
        String telefono = soloDigitos(vista.getTelefono(), "Telefono");
        int edad = enteroEnRango(vista.getEdad(), "Edad", 1, 120);
        int estrato = enteroEnRango(vista.getEstrato(), "Estrato", 1, 6);
        EstadoCivil estadoCivil = EstadoCivil.desdeTexto(vista.getEstadoCivil());
        if (estadoCivil == null) {
            throw new IllegalArgumentException(
                "Estado civil no valido. Escriba: Soltero, Casado, Viudo, Divorciado o Union libre.");
        }
        boolean cabezaHogar = vista.isCabezaHogar();

        // --- Datos segun la clasificacion ---
        Persona persona;
        if (tipo.equals(JFSalud.TIPO_SALUD)) {
            String institucion = textoObligatorio(vista.getInstitucion(), "Institucion de salud");
            String especialidad = textoObligatorio(vista.getEspecialidad(), "Especialidad");
            double bioseguridad = valorEnPesos(vista.getElementoBioseguridad(), "Elemento Bioseguridad");
            double medicina = valorEnPesos(vista.getMedicinaProfesional(), "Medicina");
            persona = new ProfesionalSalud(tipoDocumento, nombre, apellido, documento, telefono, direccion,
                edad, estadoCivil, estrato, cabezaHogar, institucion, especialidad,
                new Implementos(bioseguridad, medicina));

        } else if (tipo.equals(JFSalud.TIPO_DOCENTE)) {
            String institucion = textoObligatorio(vista.getInstitucion(), "Institucion educativa");
            Nivel nivel = Nivel.desdeEtiqueta(vista.getNivel());
            if (nivel == null) {
                throw new IllegalArgumentException("Seleccione el nivel educativo.");
            }
            double implementos = valorEnPesos(vista.getImplementos(), "Implementos Tecnologicos");
            double servicios = valorEnPesos(vista.getServicios(), "Servicio Internet/Energia");
            persona = new Docente(tipoDocumento, nombre, apellido, documento, telefono, direccion,
                edad, estadoCivil, estrato, cabezaHogar, institucion, nivel,
                new Servicios(implementos, servicios));

        } else {
            // Ciudadano: solo reciben bono los estratos 1 y 2 del Sisben
            if (estrato > 2) {
                throw new IllegalArgumentException(
                    "Solo los ciudadanos de estrato 1 y 2 (Sisben) reciben el bono de "
                    + Bono.formatear(Bono.MONTO_CIUDADANO) + ".");
            }
            double medicina = valorEnPesos(vista.getMedicinaCiudadano(), "Medicina");
            double canasta = valorEnPesos(vista.getCanastaFamiliar(), "Canasta Familiar");
            persona = new Ciudadano(tipoDocumento, nombre, apellido, documento, telefono, direccion,
                edad, estadoCivil, estrato, cabezaHogar, new Medicina(medicina, canasta));
        }

        validarDistribucion(persona);
        return persona;
    }

    /**
     * La suma de lo distribuido no puede superar el monto del bono de su clasificacion.
     */
    private void validarDistribucion(Persona persona) {
        if (!persona.distribucionValida()) {
            throw new IllegalArgumentException(
                "La distribucion del bono supera el monto permitido.\n"
                + "Bono de " + persona.getClasificacion() + ": " + Bono.formatear(persona.getBono().getMonto()) + "\n"
                + "Total distribuido: " + Bono.formatear(persona.getTotalDistribuido()) + "\n"
                + "Exceso: " + Bono.formatear(-persona.getSaldoBono()));
        }
    }

    // ------------------------------------------------------------------
    // Buscar
    // ------------------------------------------------------------------

    private void buscar() {
        String documento = vista.getDocumento();
        if (documento.isEmpty()) {
            vista.mostrarError("Escriba el numero de documento que desea buscar.");
            return;
        }
        Persona persona = buscarPorDocumento(documento);
        if (persona == null) {
            vista.mostrarError("No se encontro ninguna persona con el documento " + documento + ".");
            return;
        }
        mostrarPersona(persona);
        vista.mostrarMensaje("Persona encontrada", persona.getResumen());
    }

    private Persona buscarPorDocumento(String documento) {
        for (Persona persona : personas) {
            if (persona.getDocumento().equals(documento)) {
                return persona;
            }
        }
        return null;
    }

    /**
     * Muestra en el formulario los datos de la persona: la clasificacion en
     * la lista "Tipo" y los campos propios de su tipo.
     */
    private void mostrarPersona(Persona persona) {
        vista.setTipoDocumento(persona.getTipoDocumento().getSiglas());
        vista.setDocumento(persona.getDocumento());
        vista.setNombre(persona.getNombre());
        vista.setApellido(persona.getApellido());
        vista.setDireccion(persona.getDireccion());
        vista.setTelefono(persona.getTelefono());
        vista.setEdad(String.valueOf(persona.getEdad()));
        vista.setEstrato(String.valueOf(persona.getSisben()));
        vista.setEstadoCivil(persona.getEstadoCivil().getEtiqueta());
        vista.setCabezaHogar(persona.isCabezaHogar());

        if (persona instanceof ProfesionalSalud) {
            ProfesionalSalud salud = (ProfesionalSalud) persona;
            vista.setTipo(JFSalud.TIPO_SALUD);
            vista.setInstitucion(salud.getInstitucionSalud());
            vista.setEspecialidad(salud.getEspecialidad());
            vista.setElementoBioseguridad(pesos(salud.getImplementos().getElementosBioseguridad()));
            vista.setMedicinaProfesional(pesos(salud.getImplementos().getMedicina()));

        } else if (persona instanceof Docente) {
            Docente docente = (Docente) persona;
            vista.setTipo(JFSalud.TIPO_DOCENTE);
            vista.setInstitucion(docente.getInstitucionEducativa());
            vista.setNivel(docente.getNivel().getEtiqueta());
            vista.setImplementos(pesos(docente.getServicios().getImplementosTecnologicos()));
            vista.setServicios(pesos(docente.getServicios().getServicios()));

        } else if (persona instanceof Ciudadano) {
            Ciudadano ciudadano = (Ciudadano) persona;
            vista.setTipo(JFSalud.TIPO_CIUDADANO);
            vista.setMedicinaCiudadano(pesos(ciudadano.getMedicina().getMedicina()));
            vista.setCanastaFamiliar(pesos(ciudadano.getMedicina().getCanastaFamiliar()));
        }
    }

    // ------------------------------------------------------------------
    // Validaciones de texto
    // ------------------------------------------------------------------

    private String textoObligatorio(String texto, String campo) {
        if (texto.isEmpty()) {
            throw new IllegalArgumentException("El campo " + campo + " es obligatorio.");
        }
        return texto;
    }

    private String soloDigitos(String texto, String campo) {
        textoObligatorio(texto, campo);
        if (!texto.matches("\\d+")) {
            throw new IllegalArgumentException("El campo " + campo + " debe contener solo numeros.");
        }
        return texto;
    }

    private int enteroEnRango(String texto, String campo, int minimo, int maximo) {
        textoObligatorio(texto, campo);
        if (!texto.matches("\\d{1,3}")) {
            throw new IllegalArgumentException("El campo " + campo + " debe ser un numero entero.");
        }
        int valor = Integer.parseInt(texto);
        if (valor < minimo || valor > maximo) {
            throw new IllegalArgumentException(
                "El campo " + campo + " debe estar entre " + minimo + " y " + maximo + ".");
        }
        return valor;
    }

    /**
     * Convierte un valor en pesos escrito en el formulario. Acepta "50000",
     * "50.000" o "$50.000". Un campo vacio se toma como 0.
     */
    private double valorEnPesos(String texto, String campo) {
        String limpio = texto.replace("$", "").replace(".", "").replace(",", "").replace(" ", "");
        if (limpio.isEmpty()) {
            return 0;
        }
        if (!limpio.matches("\\d{1,12}")) {
            throw new IllegalArgumentException("El valor de " + campo + " debe ser un monto en pesos (solo numeros).");
        }
        return Double.parseDouble(limpio);
    }

    private String pesos(double valor) {
        return String.valueOf((long) valor);
    }
}
