package vista;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.ActionListener;
/**
 * Formulario de registro de ciudadanos y distribucion de bonos.
 * Esta clase solo se encarga de mostrar los datos y de habilitar o
 * deshabilitar componentes; la logica esta en el controlador.
 */
public class JFSalud extends JFrame
{
    // Valores de la lista desplegable "Tipo"
    public static final String TIPO_SALUD = "Profesional de la Salud";
    public static final String TIPO_DOCENTE = "Docente";
    public static final String TIPO_CIUDADANO = "Ciudadano";

    // Comandos que identifican cada evento ante el controlador
    public static final String CMD_GUARDAR = "GUARDAR";
    public static final String CMD_LIMPIAR = "LIMPIAR";
    public static final String CMD_BUSCAR = "BUSCAR";
    public static final String CMD_TIPO = "TIPO";

    private JLabel lblTipoDoc, lblDocumento, lblNombre, lblApellido, lblDireccion, lblTelefono, lblEdad, lblEstrato, lblEstadoCivil,
    lblTipo, lblInstitucion, lblEspecialidad, lblNivel, lblElementoBioseguridad, lblMedicina, lblImplementos, lblServicios, lblMedicin, lblCanastaFamiliar;
    private JTextField txtDocumento, txtNombre, txtApellido, txtDireccion, txtTelefono, txtEdad, txtEstrato, txtEstadoCivil,
    txtInstitucion, txtEspecialidad, txtElementoBioseguridad, txtMedicina, txtImplementos, txtServicios, txtMedicin, txtCanastaFamiliar;
    private JComboBox<String> comboTipoDoc, comboTipo, comboNivel;
    private JCheckBox chkCabezaHogar;
    private JButton btnGuardar, btnLimpiar, btnBuscar;

    // Paneles de distribucion (panel 3, 4 y 5) y sus bordes, para poder habilitarlos
    private JPanel distribucionPrSalud, bonoDoc, DistribuBono;
    private TitledBorder bordeConTitulo3, bordeConTitulo4, bordeConTitulo5;

    public JFSalud (){
        setTitle ("Registro de Ciudadanos - BONOS");
        setSize (800,800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        JPanel registro= new JPanel (new BorderLayout());
        setLayout(new GridLayout(1,2,10,0));
        JPanel campos = new JPanel(new GridLayout(1,2,10,0));

        Border lineaGris = BorderFactory.createLineBorder(Color.GRAY, 1);
        TitledBorder bordeConTitulo = BorderFactory.createTitledBorder(lineaGris, "Registro Datos Basicos");
        bordeConTitulo.setTitleColor(Color.BLUE);

        JPanel datos1 = new JPanel (new GridLayout (13,1,5,5));
        lblTipoDoc = new JLabel ("Tipo de Documento");
        lblDocumento = new JLabel ("Documento");
        lblNombre = new JLabel ("Nombre");
        lblApellido = new JLabel ("Apellido");
        lblDireccion = new JLabel ("Direccion");
        lblTelefono = new JLabel ("Telefono");
        lblEdad = new JLabel ("Edad");
        lblEstrato = new JLabel ("Estrato");
        lblEstadoCivil = new JLabel ("Estado Civil");
        lblTipo = new JLabel ("Tipo");
        lblInstitucion = new JLabel ("Institucion");
        lblEspecialidad = new JLabel ("Especialidad");
        lblNivel= new JLabel ("Nivel");

        JPanel datos2 = new JPanel (new GridLayout (13,1,5,5));
        comboTipoDoc = new JComboBox<>(new String[]{"", "C.C", "T.I"});
        txtDocumento = new JTextField ("");
        txtNombre = new JTextField ("");
        txtApellido = new JTextField ("");
        txtDireccion = new JTextField ("");
        txtTelefono = new JTextField ("");
        txtEdad = new JTextField ("");
        txtEstrato = new JTextField ("");
        txtEstadoCivil = new JTextField ("");
        comboTipo = new JComboBox<>(new String[]{"", TIPO_SALUD, TIPO_DOCENTE, TIPO_CIUDADANO});
        comboNivel = new JComboBox<>(new String[]{"", "Primaria", "Secundaria", "Tecnico", "Pregrado", "Posgrado"});
        txtInstitucion = new JTextField ("");
        txtEspecialidad = new JTextField ("");

        JPanel check= new JPanel();
        chkCabezaHogar = new JCheckBox("Cabeza de hogar");

        JPanel registro2= new JPanel(new GridLayout(2,1,0,5));

        JPanel botDis= new JPanel(new GridLayout(2,1));

        JPanel botones= new JPanel (new GridLayout (1,3,5,5));

        TitledBorder bordeConTitulo2 = BorderFactory.createTitledBorder(lineaGris, "Panel Botones");
        bordeConTitulo2.setTitleColor(Color.BLUE);

        btnGuardar= new JButton("Guardar");
        btnLimpiar= new JButton("Limpiar");
        btnBuscar= new JButton("Buscar");

        // Panel 3: distribucion del bono del profesional de la salud
        distribucionPrSalud= new JPanel (new GridLayout (1,2,5,5));

        bordeConTitulo3 = BorderFactory.createTitledBorder(lineaGris, "Distribucion Bono Prof Salud");
        bordeConTitulo3.setTitleColor(Color.GRAY);

        JPanel labelElem = new JPanel (new GridLayout(2,1,5,5));
        lblElementoBioseguridad = new JLabel ("Elemento Bioseguridad");
        lblMedicina = new JLabel ("Medicina");

        JPanel textoElem = new JPanel (new GridLayout(2,1,5,5));
        txtElementoBioseguridad = new JTextField ("");
        txtMedicina = new JTextField ("");

        JPanel docPer= new JPanel(new GridLayout(2,1));

        // Panel 4: distribucion del bono del docente
        bonoDoc= new JPanel (new GridLayout (1,2,5,5));

        bordeConTitulo4 = BorderFactory.createTitledBorder(lineaGris, "Distribucion Bono Docente");
        bordeConTitulo4.setTitleColor(Color.GRAY);

        JPanel labelDis = new JPanel (new GridLayout(2,1,5,5));
        lblImplementos = new JLabel ("Implementos Tecnológicos");
        lblServicios = new JLabel ("Servicio Internet/Energía");

        JPanel textoDis = new JPanel (new GridLayout(2,1,5,5));
        txtImplementos = new JTextField ("");
        txtServicios = new JTextField ("");

        // Panel 5: distribucion del bono de la persona independiente (ciudadano)
        DistribuBono= new JPanel (new GridLayout (1,2,5,5));
        bordeConTitulo5 = BorderFactory.createTitledBorder(lineaGris, "Distribucion Bono Persona Independiente");
        bordeConTitulo5.setTitleColor(Color.GRAY);

        JPanel labelIndep = new JPanel(new GridLayout(2,1,5,5));
        lblMedicin = new JLabel("Medicina");
        lblCanastaFamiliar = new JLabel("Canasta Familiar");

        JPanel textoIndep = new JPanel(new GridLayout(2,1,5,5));
        txtMedicin = new JTextField("");
        txtCanastaFamiliar = new JTextField("");

        campos.add(datos1);
        campos.add(datos2);
        registro.add(campos, BorderLayout.CENTER);
        registro.add(check, BorderLayout.SOUTH);
        registro.setBorder(bordeConTitulo);
        botones.setBorder(bordeConTitulo2);
        distribucionPrSalud.setBorder(bordeConTitulo3);
        bonoDoc.setBorder(bordeConTitulo4);
        DistribuBono.setBorder(bordeConTitulo5);
        registro2.add(botDis);
        registro2.add(docPer);
        botDis.add(botones);
        botDis.add(distribucionPrSalud);
        docPer.add(bonoDoc);
        docPer.add(DistribuBono);
        DistribuBono.add(labelIndep);
        labelIndep.add(lblMedicin);
        labelIndep.add(lblCanastaFamiliar);
        DistribuBono.add(textoIndep);
        textoIndep.add(txtMedicin);
        textoIndep.add(txtCanastaFamiliar);
        datos1.add(lblTipoDoc);
        datos1.add(lblDocumento);
        datos1.add(lblNombre);
        datos1.add(lblApellido);
        datos1.add(lblDireccion);
        datos1.add(lblTelefono);
        datos1.add(lblEdad);
        datos1.add(lblEstrato);
        datos1.add(lblEstadoCivil);
        datos1.add(lblTipo);
        datos1.add(lblInstitucion);
        datos1.add(lblEspecialidad);
        datos1.add(lblNivel);
        datos2.add(comboTipoDoc);
        datos2.add(txtDocumento);
        datos2.add(txtNombre);
        datos2.add(txtApellido);
        datos2.add(txtDireccion);
        datos2.add(txtTelefono);
        datos2.add(txtEdad);
        datos2.add(txtEstrato);
        datos2.add(txtEstadoCivil);
        datos2.add(comboTipo);
        datos2.add(txtInstitucion);
        datos2.add(txtEspecialidad);
        datos2.add(comboNivel);
        botones.add(btnGuardar);
        botones.add(btnLimpiar);
        botones.add(btnBuscar);
        distribucionPrSalud.add(labelElem);
        distribucionPrSalud.add(textoElem);
        labelElem.add(lblElementoBioseguridad);
        labelElem.add(lblMedicina);
        textoElem.add(txtElementoBioseguridad);
        textoElem.add(txtMedicina);
        bonoDoc.add(labelDis);
        bonoDoc.add(textoDis);
        labelDis.add(lblImplementos);
        labelDis.add(lblServicios);
        textoDis.add(txtImplementos);
        textoDis.add(txtServicios);
        check.add(chkCabezaHogar);

        add(registro);
        add(registro2);

        // Al iniciar no hay tipo seleccionado: todo lo dependiente del tipo queda deshabilitado
        habilitarSegunTipo("");

        setVisible (true);
    }

    // ------------------------------------------------------------------
    // Conexion con el controlador
    // ------------------------------------------------------------------

    /**
     * Registra el controlador como oyente de los botones y de la lista "Tipo".
     */
    public void setControlador(ActionListener controlador) {
        btnGuardar.setActionCommand(CMD_GUARDAR);
        btnLimpiar.setActionCommand(CMD_LIMPIAR);
        btnBuscar.setActionCommand(CMD_BUSCAR);
        comboTipo.setActionCommand(CMD_TIPO);

        btnGuardar.addActionListener(controlador);
        btnLimpiar.addActionListener(controlador);
        btnBuscar.addActionListener(controlador);
        comboTipo.addActionListener(controlador);
    }

    // ------------------------------------------------------------------
    // Habilitar / deshabilitar segun el tipo de persona
    // ------------------------------------------------------------------

    /**
     * Habilita solo los campos y el panel de distribucion que corresponden
     * al tipo seleccionado:
     *  - Profesional de la Salud: institucion, especialidad y panel 3
     *  - Docente: institucion, nivel y panel 4
     *  - Ciudadano: panel 5
     * Lo que queda deshabilitado tambien se limpia.
     */
    public void habilitarSegunTipo(String tipo) {
        boolean salud = TIPO_SALUD.equals(tipo);
        boolean docente = TIPO_DOCENTE.equals(tipo);
        boolean ciudadano = TIPO_CIUDADANO.equals(tipo);

        habilitarCampo(txtInstitucion, salud || docente);
        habilitarCampo(txtEspecialidad, salud);
        habilitarCampo(comboNivel, docente);

        habilitarPanel(distribucionPrSalud, bordeConTitulo3, salud);
        habilitarPanel(bonoDoc, bordeConTitulo4, docente);
        habilitarPanel(DistribuBono, bordeConTitulo5, ciudadano);
    }

    private void habilitarCampo(JComponent campo, boolean habilitar) {
        campo.setEnabled(habilitar);
        if (campo instanceof JTextField) {
            // un campo de texto deshabilitado se pinta gris para que se note
            campo.setBackground(habilitar ? Color.WHITE : new Color(225, 225, 225));
        }
        if (!habilitar) {
            limpiarComponente(campo);
        }
    }

    private void habilitarPanel(JPanel panel, TitledBorder borde, boolean habilitar) {
        panel.setEnabled(habilitar);
        habilitarRecursivo(panel, habilitar);
        borde.setTitleColor(habilitar ? Color.BLUE : Color.GRAY);
        panel.repaint();
    }

    // Deshabilitar un JPanel no deshabilita sus hijos, por eso se recorre
    private void habilitarRecursivo(Container contenedor, boolean habilitar) {
        for (Component hijo : contenedor.getComponents()) {
            if (hijo instanceof JComponent) {
                habilitarCampo((JComponent) hijo, habilitar);
            } else {
                hijo.setEnabled(habilitar);
            }
            if (hijo instanceof Container) {
                habilitarRecursivo((Container) hijo, habilitar);
            }
        }
    }

    private void limpiarComponente(JComponent componente) {
        if (componente instanceof JTextField) {
            ((JTextField) componente).setText("");
        } else if (componente instanceof JComboBox) {
            ((JComboBox<?>) componente).setSelectedIndex(0);
        }
    }

    // ------------------------------------------------------------------
    // Limpiar
    // ------------------------------------------------------------------

    /**
     * Deja el formulario como al iniciar: sin datos y con los campos y
     * paneles dependientes del tipo deshabilitados.
     */
    public void limpiar() {
        comboTipoDoc.setSelectedIndex(0);
        txtDocumento.setText("");
        txtNombre.setText("");
        txtApellido.setText("");
        txtDireccion.setText("");
        txtTelefono.setText("");
        txtEdad.setText("");
        txtEstrato.setText("");
        txtEstadoCivil.setText("");
        comboTipo.setSelectedIndex(0);
        chkCabezaHogar.setSelected(false);
        habilitarSegunTipo("");   // limpia y deshabilita institucion, especialidad, nivel y paneles
        txtDocumento.requestFocus();
    }

    // ------------------------------------------------------------------
    // Mensajes
    // ------------------------------------------------------------------

    public void mostrarMensaje(String titulo, String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    public void mostrarError(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje, "Datos no validos", JOptionPane.ERROR_MESSAGE);
    }

    // ------------------------------------------------------------------
    // Getters: devuelven lo escrito en el formulario
    // ------------------------------------------------------------------

    public String getTipoDocumento() { return seleccionado(comboTipoDoc); }
    public String getDocumento() { return txtDocumento.getText().trim(); }
    public String getNombre() { return txtNombre.getText().trim(); }
    public String getApellido() { return txtApellido.getText().trim(); }
    public String getDireccion() { return txtDireccion.getText().trim(); }
    public String getTelefono() { return txtTelefono.getText().trim(); }
    public String getEdad() { return txtEdad.getText().trim(); }
    public String getEstrato() { return txtEstrato.getText().trim(); }
    public String getEstadoCivil() { return txtEstadoCivil.getText().trim(); }
    public String getTipo() { return seleccionado(comboTipo); }
    public String getInstitucion() { return txtInstitucion.getText().trim(); }
    public String getEspecialidad() { return txtEspecialidad.getText().trim(); }
    public String getNivel() { return seleccionado(comboNivel); }
    public boolean isCabezaHogar() { return chkCabezaHogar.isSelected(); }

    // Panel 3 (profesional de la salud)
    public String getElementoBioseguridad() { return txtElementoBioseguridad.getText().trim(); }
    public String getMedicinaProfesional() { return txtMedicina.getText().trim(); }
    // Panel 4 (docente)
    public String getImplementos() { return txtImplementos.getText().trim(); }
    public String getServicios() { return txtServicios.getText().trim(); }
    // Panel 5 (ciudadano)
    public String getMedicinaCiudadano() { return txtMedicin.getText().trim(); }
    public String getCanastaFamiliar() { return txtCanastaFamiliar.getText().trim(); }

    private String seleccionado(JComboBox<String> combo) {
        Object item = combo.getSelectedItem();
        return item == null ? "" : item.toString();
    }

    // ------------------------------------------------------------------
    // Setters: muestran datos en el formulario (usados al buscar)
    // ------------------------------------------------------------------

    public void setTipoDocumento(String valor) { comboTipoDoc.setSelectedItem(valor); }
    public void setDocumento(String valor) { txtDocumento.setText(valor); }
    public void setNombre(String valor) { txtNombre.setText(valor); }
    public void setApellido(String valor) { txtApellido.setText(valor); }
    public void setDireccion(String valor) { txtDireccion.setText(valor); }
    public void setTelefono(String valor) { txtTelefono.setText(valor); }
    public void setEdad(String valor) { txtEdad.setText(valor); }
    public void setEstrato(String valor) { txtEstrato.setText(valor); }
    public void setEstadoCivil(String valor) { txtEstadoCivil.setText(valor); }
    public void setCabezaHogar(boolean valor) { chkCabezaHogar.setSelected(valor); }
    public void setInstitucion(String valor) { txtInstitucion.setText(valor); }
    public void setEspecialidad(String valor) { txtEspecialidad.setText(valor); }
    public void setNivel(String valor) { comboNivel.setSelectedItem(valor); }

    /** Selecciona el tipo y habilita lo que le corresponde. */
    public void setTipo(String valor) {
        comboTipo.setSelectedItem(valor);
        habilitarSegunTipo(valor);
    }

    public void setElementoBioseguridad(String valor) { txtElementoBioseguridad.setText(valor); }
    public void setMedicinaProfesional(String valor) { txtMedicina.setText(valor); }
    public void setImplementos(String valor) { txtImplementos.setText(valor); }
    public void setServicios(String valor) { txtServicios.setText(valor); }
    public void setMedicinaCiudadano(String valor) { txtMedicin.setText(valor); }
    public void setCanastaFamiliar(String valor) { txtCanastaFamiliar.setText(valor); }
}
