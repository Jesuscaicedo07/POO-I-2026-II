------------------------------------------------------------------------
SaludPublica - Registro de Ciudadanos y distribucion de bonos
------------------------------------------------------------------------

PROJECT TITLE: SaludPublica (Segundo Previo POO I)

PURPOSE OF PROJECT:
  Registrar personas que reciben un bono del Estado por la emergencia de
  salud publica y validar como distribuyen el bono:
    - Profesional de la Salud: bono de $350.000 (bioseguridad y medicina)
    - Docente:                 bono de $100.000 (implementos tecnologicos
                               y servicios de luz o internet)
    - Ciudadano (estrato 1-2): bono de $160.000 (medicina y canasta familiar)
  La suma distribuida nunca puede superar el monto del bono.

ARQUITECTURA (modelo - vista - controlador):
  modelo       Persona (clase padre abstracta), ProfesionalSalud, Docente,
               Ciudadano, Bono, Implementos, Servicios, Medicina y los
               enumerados TipoDocumento, EstadoCivil y Nivel.
  vista        JFSalud: formulario Swing. Solo muestra datos y habilita o
               deshabilita campos y paneles segun el tipo de persona.
  controlador  ControladorSalud: atiende Guardar, Limpiar y Buscar, valida
               los datos y guarda todas las personas en un
               ArrayList<Persona> (polimorfismo).

HOW TO START THIS PROJECT:
  En BlueJ: clic derecho sobre la clase ControladorSalud -> new ControladorSalud()
  o ejecutar su metodo estatico main.

USER INSTRUCTIONS:
  1. Elija el "Tipo" de persona: se habilitan solo los campos y el panel de
     distribucion que le corresponden.
  2. Complete los datos y los valores de la distribucion (se aceptan
     formatos como 50000, 50.000 o $50.000) y pulse Guardar.
  3. Para consultar una persona escriba su documento y pulse Buscar:
     se muestra su clasificacion y los datos segun su tipo.
  4. Limpiar deja el formulario como al iniciar.

AUTHORS: (escriba su nombre)
VERSION or DATE: Octubre 2026
