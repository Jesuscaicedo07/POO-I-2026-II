package vista;

 import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
public class FrmPedido extends JFrame {
//==========================================
// COMPONENTES DEL FORMULARIO
//==========================================
// Pedido
public JTextField txtNumeroPedido;
// Cliente
public JTextField txtCedula;
public JTextField txtNombreCliente;
// Producto
public JTextField txtCodigoProducto;
public JTextField txtNombreProducto;
public JTextField txtPrecio;
// Botones
public JButton btnAgregarProducto;
public JButton btnEliminarProducto;
public JButton btnNuevoPedido;
public JButton btnLimpiar;
public JButton btnSalir;
// Tabla
public JTable tablaProductos;
public DefaultTableModel modeloTabla;
// Total
public JLabel lblTotal;


    public FrmPedido(){
        // Configuración de la ventana
setTitle("Gestión de Pedidos");
setSize(900, 650);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
setLocationRelativeTo(null);
// Layout principal
setLayout(new BorderLayout(10, 10));
// Crear componentes
crearTitulo();
crearPanelCentral();
crearPanelInferior();

        setVisible(true);
    }
    
    private void crearTitulo() {
JLabel lblTitulo = new JLabel(
"GESTIÓN DE PEDIDOS",
SwingConstants.CENTER
);
lblTitulo.setFont(
new Font("Arial", Font.BOLD, 28)
);
lblTitulo.setBorder(
BorderFactory.createEmptyBorder(15, 10, 15, 10)
);
add(lblTitulo, BorderLayout.NORTH);
}

private void crearPanelCentral() {
JPanel panelCentral = new JPanel();
panelCentral.setLayout(
new BoxLayout(panelCentral, BoxLayout.Y_AXIS)
);
panelCentral.setBorder(
BorderFactory.createEmptyBorder(10, 20, 10, 20)
);
panelCentral.add(crearPanelPedidoCliente());
panelCentral.add(
Box.createVerticalStrut(10)
);
panelCentral.add(crearPanelProducto());
panelCentral.add(
Box.createVerticalStrut(10)
);
panelCentral.add(crearPanelTabla());
add(panelCentral, BorderLayout.CENTER);}

 private JPanel crearPanelPedidoCliente() {
JPanel panel = new JPanel(
new GridLayout(1, 2, 15, 0)
);

JPanel panelPedido = new JPanel(
new GridBagLayout()
);
panelPedido.setBorder(
BorderFactory.createTitledBorder(
"Datos del Pedido"
)
);
GridBagConstraints gbc = new
GridBagConstraints();
gbc.insets = new Insets(10, 10, 10, 10);
gbc.gridx = 0;
gbc.gridy = 0;
panelPedido.add(
new JLabel("Número de pedido:"),
gbc
);
txtNumeroPedido = new JTextField(12);
gbc.gridx = 1;
panelPedido.add(
txtNumeroPedido,
gbc
);

JPanel panelCliente = new JPanel(new GridBagLayout()
);
panelCliente.setBorder(
BorderFactory.createTitledBorder(
"Datos del Cliente"
)
);
GridBagConstraints gbcCliente =
new GridBagConstraints();
gbcCliente.insets =
new Insets(5, 10, 5, 10);
// Cédula
gbcCliente.gridx = 0;
gbcCliente.gridy = 0;
panelCliente.add(
new JLabel("Cédula:"),
gbcCliente
);
txtCedula = new JTextField(15);
gbcCliente.gridx = 1;
panelCliente.add(
txtCedula,
gbcCliente
);
// Nombre�
gbcCliente.gridx = 0;
gbcCliente.gridy = 1;
panelCliente.add(
new JLabel("Nombre:"),
gbcCliente
);
txtNombreCliente =
new JTextField(15);
gbcCliente.gridx = 1;
panelCliente.add(
txtNombreCliente,
gbcCliente
);
panel.add(panelPedido);
panel.add(panelCliente);
return panel;
}
//==========================================
// PANEL PRODUCTO
//==========================================
private JPanel crearPanelProducto() {
JPanel panel = new JPanel(
new FlowLayout(FlowLayout.LEFT, 15, 15)
);
panel.setBorder(
BorderFactory.createTitledBorder(
"Datos del Producto"
)
);
// Código
panel.add(
new JLabel("Código:")
);
txtCodigoProducto =
new JTextField(8);
panel.add(
txtCodigoProducto
);
// Nombre
panel.add(
new JLabel("Nombre:")
);
txtNombreProducto =
new JTextField(15);
panel.add(
txtNombreProducto
);
// Precio
panel.add(
new JLabel("Precio:")
);
txtPrecio =
new JTextField(10);
panel.add(
txtPrecio
);
// Botón agregar
btnAgregarProducto =
new JButton("Agregar Producto");
panel.add(
btnAgregarProducto
);
return panel;
}
// TABLA DE PRODUCTOS//
private JPanel crearPanelTabla() {
JPanel panel = new JPanel(
new BorderLayout(10, 10)
);
panel.setBorder(
BorderFactory.createTitledBorder(
"Productos del Pedido"
)
);
// Columnas de la tabla
String[] columnas = {
"Código",
"Nombre",
"Precio"
};
modeloTabla =
new DefaultTableModel(columnas, 0) {
@Override
public boolean isCellEditable(
int fila,
int columna
) {
return false;
}
};
tablaProductos =
new JTable(modeloTabla);
tablaProductos.setRowHeight(25);
JScrollPane scroll =
new JScrollPane(tablaProductos);
panel.add(
scroll,
BorderLayout.CENTER
);
// Botón eliminar
btnEliminarProducto =
new JButton("Eliminar Producto");
JPanel panelEliminar =
new JPanel();
panelEliminar.add(
btnEliminarProducto
);
panel.add(
panelEliminar,
BorderLayout.EAST
);
return panel;
}
//// PANEL INFERIOR
//
private void crearPanelInferior() {
JPanel panelInferior =
new JPanel();
panelInferior.setLayout(new BoxLayout(panelInferior,
BoxLayout.Y_AXIS
)
);
// ------------------------------
// TOTAL
// ------------------------------
JPanel panelTotal =
new JPanel(
new FlowLayout(
FlowLayout.RIGHT
)
);
JLabel lblTextoTotal =
new JLabel(
"TOTAL DEL PEDIDO:"
);
lblTextoTotal.setFont(
new Font(
"Arial",
Font.BOLD,
18
)
);
lblTotal =
new JLabel("$ 0");
lblTotal.setFont(
new Font(
"Arial",
Font.BOLD,
24
)
);
panelTotal.add(
lblTextoTotal
);
panelTotal.add(
lblTotal
);
// ------------------------------
// BOTONES
// ------------------------------
JPanel panelBotones =
new JPanel(
new FlowLayout(
FlowLayout.CENTER,
30,
10
)
);
btnNuevoPedido =
new JButton(
"Nuevo Pedido"
);
btnLimpiar =
new JButton(
"Limpiar Campos"
);
btnSalir =
new JButton(
"Salir"
);
panelBotones.add(
btnNuevoPedido
);
panelBotones.add(
btnLimpiar
);
panelBotones.add(
btnSalir
);
panelInferior.add(
panelTotal
);
panelInferior.add(
panelBotones
);
add(
panelInferior,
BorderLayout.SOUTH
);
}
}
   
    
