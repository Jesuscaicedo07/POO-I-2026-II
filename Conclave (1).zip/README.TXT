Conclave - MVC (modelo, vista, controlador). Ejecutar controlador.Principal.
