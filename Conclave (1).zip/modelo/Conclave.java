package modelo;

/** Rondas de votacion. Se elige Papa cuando alguien llega a 2/3 de los electores. */
public class Conclave
{
    private Colegio colegio;
    private int ronda;
    private int votosEmitidos;
    private Cardenal papa;

    public Conclave(Colegio colegio){
        this.colegio = colegio;
        this.ronda = 1;
    }

    /** Registra un voto. false si ya votaron todos los electores o ya hay Papa. */
    public boolean votar(Cardenal candidato){
        if (hayPapa() || votosEmitidos >= getElectores()) {
            return false;
        }
        candidato.registrarVoto();
        votosEmitidos++;
        if (candidato.getVotos() >= getVotosNecesarios()) {
            papa = candidato;
        }
        return true;
    }

    /** Pasa a la siguiente ronda con los votos en cero. Solo si no hay Papa y ya votaron todos. */
    public boolean siguienteRonda(){
        if (hayPapa() || votosEmitidos < getElectores()) {
            return false;
        }
        for (Cardenal c : colegio.getCardenales()) {
            c.reiniciarVotos();
        }
        votosEmitidos = 0;
        ronda++;
        return true;
    }

    public int getElectores(){ return colegio.contarElectores(); }

    /** Dos tercios de los electores, redondeado hacia arriba. */
    public int getVotosNecesarios(){ return (2 * getElectores() + 2) / 3; }

    public Colegio getColegio(){ return colegio; }
    public int getRonda(){ return ronda; }
    public int getVotosEmitidos(){ return votosEmitidos; }
    public Cardenal getPapa(){ return papa; }
    public boolean hayPapa(){ return papa != null; }
}
