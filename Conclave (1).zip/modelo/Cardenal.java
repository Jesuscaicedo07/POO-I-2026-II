package modelo;

public class Cardenal
{
    private TipoCardenal tipoCardenal;
    private Pais pais;
    private String nombre;
    private int edad;
    private boolean enfermo=false;
    private int votos;

    public Cardenal(){}

    public Cardenal(TipoCardenal tipoCardenal, Pais pais, String nombre, int edad, boolean enfermo){
        this.tipoCardenal = tipoCardenal;
        this.pais = pais;
        this.nombre = nombre;
        this.edad = edad;
        this.enfermo = enfermo;
        this.votos = 0;
    }

    /** Puede votar si tiene menos de 80 años y no esta enfermo. */
    public boolean puedeVotar(){
        return edad < 80 && !enfermo;
    }

    public void registrarVoto() {
        this.votos++;
    }

    public int getVotos() {
        return this.votos;
    }

    public void reiniciarVotos() {
        this.votos = 0;
    }

    public TipoCardenal getTipoCardenal(){ return this.tipoCardenal; }
    public void setTipoCardenal(TipoCardenal tipoCardenal){ this.tipoCardenal = tipoCardenal; }

    public Pais getPais(){ return this.pais; }
    public void setPais(Pais pais){ this.pais = pais; }

    public String getNombre() { return this.nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getEdad(){ return this.edad; }
    public void setEdad(int edad){ this.edad = edad; }

    public boolean isEnfermo() { return this.enfermo; }
    public void setEnfermo(boolean enfermo) { this.enfermo = enfermo; }
}
