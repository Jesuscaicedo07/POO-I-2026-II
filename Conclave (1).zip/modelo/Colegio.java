package modelo;

import java.util.ArrayList;

/** Colegio cardenalicio: la lista de cardenales. */
public class Colegio
{
    private ArrayList<Cardenal> cardenales;

    public Colegio(){
        cardenales = new ArrayList<Cardenal>();
    }

    public void agregarCardenal(Cardenal c){
        cardenales.add(c);
    }

    public ArrayList<Cardenal> getCardenales(){
        return cardenales;
    }

    /** Cantidad de cardenales que pueden votar (menores de 80 años y sanos). */
    public int contarElectores(){
        int total = 0;
        for (Cardenal c : cardenales) {
            if (c.puedeVotar()) total++;
        }
        return total;
    }
}
