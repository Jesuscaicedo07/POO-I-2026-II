package controlador;

import modelo.*;
import vista.JFConclave;

public class Principal
{
    public static void main(String[] args) {
        Colegio colegio = new Colegio();
        colegio.agregarCardenal(new Cardenal(TipoCardenal.OBISPO, Pais.FILIPINAS, "Cardenal Luis Antonio Tagle", 69, false));
        colegio.agregarCardenal(new Cardenal(TipoCardenal.OBISPO, Pais.COLOMBIA, "Cardenal Luis José Rueda", 64, false));
        colegio.agregarCardenal(new Cardenal(TipoCardenal.OBISPO, Pais.FRANCIA, "Cardenal Robert Sarah", 81, false));
        colegio.agregarCardenal(new Cardenal(TipoCardenal.OBISPO, Pais.KENIA, "Cardenal John Njue", 80, true));
        colegio.agregarCardenal(new Cardenal(TipoCardenal.OBISPO, Pais.UCRANIA, "Cardenal Mykola Bychok", 46, false));

        new Controlador(new JFConclave(), new Conclave(colegio)).iniciar();
    }
}
