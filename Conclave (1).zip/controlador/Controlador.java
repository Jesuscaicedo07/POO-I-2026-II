package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import modelo.Cardenal;
import modelo.Conclave;
import vista.JFConclave;

public class Controlador implements ActionListener
{
    private JFConclave vista;
    private Conclave conclave;

    public Controlador(JFConclave vista, Conclave conclave){
        this.vista = vista;
        this.conclave = conclave;
        vista.setControlador(this);
    }

    public void iniciar(){
        for (Cardenal c : conclave.getColegio().getCardenales()) {
            vista.agregarCandidato(c.getNombre());
        }
        vista.setRonda(conclave.getRonda());
        vista.mostrarTexto("Electores: " + conclave.getElectores()
            + " (no votan los de 80 años o más ni los enfermos)"
            + "\nVotos para ganar (2/3): " + conclave.getVotosNecesarios()
            + "\n\nElija un cardenal y presione Votar.");
        vista.setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        switch (e.getActionCommand()) {
            case "VOTAR":     votar(); break;
            case "MOSTRAR":   mostrar(); break;
            case "SIGUIENTE": siguienteRonda(); break;
        }
    }

    private void votar(){
        int indice = vista.getIndiceSeleccionado();
        if (indice == -1) {
            return;
        }
        Cardenal seleccionado = conclave.getColegio().getCardenales().get(indice);
        if (!conclave.votar(seleccionado)) {
            vista.mostrarTexto("Ya votaron los " + conclave.getElectores()
                + " electores. Presione Siguiente Ronda.");
            return;
        }
        mostrarEscrutinio("=== ESCRUTINIO EN TIEMPO REAL ===");
    }

    private void mostrar(){
        if (conclave.getVotosEmitidos() == 0) {
            vista.mostrarTexto("Aún no se han registrado votos en esta ronda.\n");
            return;
        }
        mostrarEscrutinio("=== RESULTADOS PARCIALES ===");
    }

    private void siguienteRonda(){
        if (conclave.hayPapa()) {
            vista.mostrarTexto("El Papa ya fue elegido: " + conclave.getPapa().getNombre());
            return;
        }
        if (!conclave.siguienteRonda()) {
            vista.mostrarTexto("Aún faltan " + (conclave.getElectores() - conclave.getVotosEmitidos())
                + " votos para cerrar la ronda.");
            return;
        }
        vista.limpiarTabla();
        vista.setRonda(conclave.getRonda());
        vista.habilitarVotar(true);
        vista.mostrarTexto("=== RONDA " + conclave.getRonda() + " INICIADA ===\n"
            + "Se han quemado las papeletas antiguas. Inicie la nueva votación.\n");
    }

    /** Llena la tabla y el texto con los votos actuales. */
    private void mostrarEscrutinio(String encabezado){
        ArrayList<Cardenal> lista = conclave.getColegio().getCardenales();
        vista.limpiarTabla();
        String texto = encabezado + "\n"
            + "Votos en esta ronda: " + conclave.getVotosEmitidos() + " de " + conclave.getElectores() + "\n"
            + "Votos para ganar (2/3): " + conclave.getVotosNecesarios() + "\n\n"
            + "Votos actuales:\n";
        for (Cardenal c : lista) {
            vista.agregarFila(c.getNombre(), c.getVotos());
            texto += "- " + c.getNombre() + ": " + c.getVotos() + " votos\n";
        }
        if (conclave.hayPapa()) {
            texto += "\n HUMO BLANCO \n\n¡HABEMUS PAPAM!\nEl cardenal: " + conclave.getPapa().getNombre()
                   + " es el nuevo Papa con " + conclave.getPapa().getVotos() + " votos.";
            vista.habilitarVotar(false);
        } else if (conclave.getVotosEmitidos() == conclave.getElectores()) {
            texto += "\nHumo Negro: Ningún candidato alcanza los 2/3 requeridos.";
        } else {
            texto += "\nVotación en curso.";
        }
        vista.mostrarTexto(texto);
    }
}
