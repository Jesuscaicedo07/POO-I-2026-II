package vista;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;


/**
 * Write a description of class JFConclave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class JFConclave extends JFrame{
    
    private JLabel lblLista, lblRonda;
    private JButton btnVotar, btnMostrar, btnSiguiente;
    private JComboBox<String> cmbLista;
    private JTextArea txtEsp;
    private JTextField txtRonda;
    private JTable tabla;
    private DefaultTableModel modelo;
    
    public JFConclave (){
        setTitle ("Votaciones conclave");
        setSize (700,700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        
        JPanel listados1 = new JPanel (new GridLayout (2,2,5,5));
        
        JPanel lista = new JPanel (new GridLayout (1,2,5,5));
        
        JPanel lista1 = new JPanel (new GridLayout (1,1,5,5));
        lblLista = new JLabel ("Lista de Cardenales");
        
        JPanel lista2 = new JPanel (new GridLayout (1,1,5,5));
        cmbLista = new JComboBox <>(); 
       
        
        JPanel botones = new JPanel(new GridLayout (1,2,5,5));
        
        JPanel boton1 = new JPanel(new GridLayout (1,1,5,5));
        boton1.setLayout(new BoxLayout(boton1,BoxLayout.X_AXIS));
        btnVotar = new JButton("Votar");
        
        
        JPanel ronda = new JPanel(new GridLayout (1,2,5,5));
        
        JPanel ronda1= new JPanel (new GridLayout (1,1,5,5));
        lblRonda = new JLabel ("Ronda Num");
        
        JPanel ronda2= new JPanel (new GridLayout (1,1,5,5));
        txtRonda = new JTextField ("1");
        txtRonda.setEditable(false); 
        
        JPanel listados2 = new JPanel (new GridLayout (2,1,5,5));
        
        JPanel mostrar = new JPanel(new GridLayout(1, 2, 10, 0)); 
        
         JPanel panelTabla = new JPanel(new BorderLayout());
        String[] columnas = {"Nombre", "Votos"};
        modelo = new DefaultTableModel(columnas, 0);
        tabla = new JTable(modelo);
        JScrollPane scrollTabla = new JScrollPane(tabla); // Envolver en scroll para ver cabeceras
        
        
        JPanel panelTexto = new JPanel(new BorderLayout());
        txtEsp = new JTextArea();
        txtEsp.setEditable(false); // Recomendado para que el usuario no digite encima
        JScrollPane scrollTexto = new JScrollPane(txtEsp); // Opcional pero recomendado por si el texto es largo
        
        
        JPanel botones22 = new JPanel(new GridLayout (1,2,5,5));
        boton1.setLayout(new BoxLayout(boton1,BoxLayout.X_AXIS));
        btnMostrar = new JButton("Mostrar Resultados");
        btnSiguiente = new JButton("Siguiente Ronda");
        
        lista.add(lista1);
        lista.add(lista2);
        botones.add(boton1);
        botones.add(ronda);
        lista1.add(lblLista, BorderLayout.WEST);
        lista2.add(cmbLista, BorderLayout.EAST);
        boton1.add(btnVotar, BorderLayout.CENTER);
        ronda.add(ronda1);
        ronda.add(ronda2);
        ronda1.add(lblRonda,BorderLayout.WEST); 
        ronda2.add(txtRonda,BorderLayout.EAST); 
        panelTabla.add(scrollTabla, BorderLayout.CENTER);
        panelTexto.add(scrollTexto, BorderLayout.CENTER);
        botones22.add(btnMostrar);
        botones22.add(btnSiguiente);
        listados1.add(lista, BorderLayout.NORTH);
        listados1.add(botones, BorderLayout.SOUTH);
        mostrar.add(panelTabla,BorderLayout.WEST);
        mostrar.add(panelTexto,BorderLayout.EAST);
        listados2.add(botones22, BorderLayout.SOUTH);
        add(listados1, BorderLayout.NORTH);
        add(mostrar,BorderLayout.CENTER);
        add(listados2, BorderLayout.SOUTH);
        
        


        
    }
    
    // ---- Conexion con el controlador ----
    public void setControlador(ActionListener c){
        btnVotar.setActionCommand("VOTAR");
        btnMostrar.setActionCommand("MOSTRAR");
        btnSiguiente.setActionCommand("SIGUIENTE");
        btnVotar.addActionListener(c);
        btnMostrar.addActionListener(c);
        btnSiguiente.addActionListener(c);
    }

    // ---- Lo que el controlador le pide a la vista ----
    public void agregarCandidato(String nombre){ cmbLista.addItem(nombre); }
    public int getIndiceSeleccionado(){ return cmbLista.getSelectedIndex(); }

    public void setRonda(int ronda){ txtRonda.setText(String.valueOf(ronda)); }
    public void mostrarTexto(String texto){ txtEsp.setText(texto); }
    public void habilitarVotar(boolean activo){ btnVotar.setEnabled(activo); }

    public void limpiarTabla(){ modelo.setRowCount(0); }
    public void agregarFila(String nombre, int votos){ modelo.addRow(new Object[]{nombre, votos}); }
}
