package modelo;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
/**
 * Write a description of class Alquiler here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Alquiler
{
    private String codigo;
    private Fecha fecha;
    private Fecha fechaEntrega;
    private List<Item> items; 
    private Cliente cliente;
    
    public Alquiler(){
        this.items = new ArrayList<>();
    }
    
    
    public Alquiler (String codigo, Fecha fecha,Fecha fechaEntrega,Cliente cliente){
        this.codigo=codigo;
        this.fecha=fecha;
        this.fechaEntrega=fechaEntrega;
        this.cliente = cliente;
        this.items = new ArrayList<>(); 
    }
    public void addItem(Item item) {
        this.items.add(item);
    }

    public double valorAlquiler() {
        return 0.0;
    }

    /** Evalua el retraso: mas de 7 dias bloquea al cliente. Devuelve el mensaje para mostrar. */
    public String multar() {
        LocalDate hoy = LocalDate.now();
        LocalDate limiteEntrega = this.fechaEntrega.toLocalDate();

        long diasDeRetraso = ChronoUnit.DAYS.between(limiteEntrega, hoy);

        if (diasDeRetraso > 7) {
            this.cliente.setBloqueado(true);
            for (Item item : items) {
                item.setEstado(Estado.CON_RETRASO);
            }
            return "ALERTA DE MULTA: El alquiler se ha excedido por " + diasDeRetraso + " dias."
                 + "\nEl cliente " + cliente.getNombre() + " ha sido bloqueado en el sistema.";
        } else if (diasDeRetraso > 0) {
            return "Aviso: Registro de retraso menor o igual a 7 dias (" + diasDeRetraso + " dias). Sin multa.";
        } else {
            return "El alquiler se encuentra totalmente al dia.";
        }
    }
    public String getCodigo(){
        return this.codigo;
    }
    public void setCodigo(String codigo){
        this.codigo=codigo;
    }
    
    public Fecha getFecha(){
        return this.fecha;
    }
    public void setFecha(Fecha fecha){
        this.fecha =fecha;
    }
    
    public Fecha getFechaEntrega(){
        return this.fechaEntrega;
    }

    public void setFechaEntrega(Fecha fechaEntrega){
        this.fechaEntrega = fechaEntrega;
    }
     public Cliente getCliente() {
         return this.cliente; 
        }
    public void setCliente(Cliente cliente) { 
        this.cliente = cliente; 
    }
    public List<Item> getItems() { return this.items; }
}