package modelo;


/**
 * Write a description of class Marca here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Marca
{
    private String nombre;
    private String direccion;
    
    public Marca(){}
    
    public Marca(String nombre, String direccion){
        this.nombre= nombre;
        this.direccion= direccion;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    
    public String getDireccion(){
        return this.direccion;
    }
    public void setDireccion(String direccion){
        this.direccion=direccion;
    }
}