package modelo;


/**
 * Enumeration class Sensibilidad - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Sensibilidad
{
    ISO_50(50), ISO_100(100), ISO_200(200), ISO_400(400), ISO_800(800), ISO_1600(1600);

    private final int valor;
    
    Sensibilidad(int valor) { 
        this.valor = valor; 
    }
        
        
    public int getValor() { 
        return valor; 
    }

}