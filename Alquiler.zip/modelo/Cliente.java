package modelo;


/**
 * Write a description of class Cliente here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cliente
{
    private String nombre;
    private String cedula;
    private String email;
    private String telefono;
    private boolean bloqueado;
    
    public Cliente (){}
    
    public Cliente (String nombre, String cedula, String email, String telefono,boolean bloqueado){
        this.nombre=nombre;
        this.cedula=cedula;
        this.email=email;
        this.telefono=telefono;
        this.bloqueado=bloqueado;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    
    public String getCedula(){
        return this.cedula;
    }
    public void setCedula(String cedula){
        this.cedula = cedula;
    }
    
    public String getEmail(){
        return this.email;
    }

    public void setEmail(String email){
        this.email = email;
    }
    
    public String getTelefono(){
        return this.telefono;
    }
    public void setTelefono(String telefono){
        this.telefono= telefono;
    }
    public boolean isBloqueado() { 
        return this.bloqueado; 
    }

    public void setBloqueado(boolean bloqueado) { 
        this.bloqueado = bloqueado; 
    }
}