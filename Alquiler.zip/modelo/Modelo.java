package modelo;


/**
 * Write a description of class Modelo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Modelo
{
    private String nombre;
    private Item item;
    
    public Modelo(){}
    
    public Modelo(String nombre, Item item){
        this.nombre = nombre;
        this.item = item;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public Item getItem(){
        return this.item;
    }
    public void setItem(Item item){
        this.item=item;
    }
}