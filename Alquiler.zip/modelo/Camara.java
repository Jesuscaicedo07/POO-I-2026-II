package modelo;


/**
 * Write a description of class Camara here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Camara
{
    private Marca marca;
    private Modelo modelo;
    private Boolean soporte;
    
    public Camara(){}
    
    public Camara (Marca marca, Modelo modelo, Boolean soporte){
        this.marca=marca;
        this.modelo=modelo;
        this.soporte=soporte;
    }
    
    public Marca getMarca(){
        return this.marca;
    }
    public void setMarca(Marca marca){
        this.marca=marca;
    }
    
    public Modelo getModelo(){
        return this.modelo;
    }
    public void setModelo(Modelo modelo){
        this.modelo=modelo;
    }
    
}