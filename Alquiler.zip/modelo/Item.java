package modelo;


/**
 * Write a description of class Item here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Item
{
    private int pegatinaR;
    private Estado estado;
    
    public Item(){}
    
    public Item(int pegatinaR, Estado estado){
        this.pegatinaR = pegatinaR;
        this.estado = estado;
    }
    
    public int getPegatinaR(){
        return this.pegatinaR;
    }
    public void setPegatinaR(int pegatinaR){
        this.pegatinaR = pegatinaR;
    }
    
    public Estado getEstado(){
        return this.estado;
    }
    
    public void setEstado(Estado estado){
        this.estado= estado;
    }
}