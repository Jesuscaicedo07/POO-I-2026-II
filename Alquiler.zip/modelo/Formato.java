package modelo;


/**
 * Enumeration class Formato - write a description of the enum class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public enum Formato
{
    F_35(35), F_110(110), F_120(120);

    private final int valor;
    
    Formato(int valor) { 
        this.valor = valor; 
    }
    
    public int getValor() { 
        return valor; 
    }
}