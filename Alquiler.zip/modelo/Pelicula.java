package modelo;


/**
 * Write a description of class Pelicula here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Pelicula
{
    private String marca;
    private String nombre;
    private Sensibilidad sensibilidad;
    private Formato formato;
    
    public Pelicula(){}
    
    public Pelicula (String marca,String nombre,Sensibilidad sensibilidad, Formato formato){
        this.marca=marca;
        this.nombre=nombre;
        this.sensibilidad=sensibilidad;
        this.formato=formato;
    }
    
    public String getMarca(){
        return this.marca;
    }
    public void setMarca(String marca){
        this.marca=marca;
    }
    
    public String getNombre(){
        return this.nombre;
    }
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    public Sensibilidad getSensibilidad(){
        return this.sensibilidad;
    }
    public void setSensibilidad(Sensibilidad sensibilidad){
        this.sensibilidad=sensibilidad;
    }
    public Formato getFormato(){
        return this.formato;
    }
    public void setFormato(Formato formato){
        this.formato=formato;
    }
}