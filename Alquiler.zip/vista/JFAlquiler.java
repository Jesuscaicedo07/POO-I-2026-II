package vista;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;

/** Solo dibuja la interfaz. Los eventos los atiende el controlador. */
public class JFAlquiler extends JFrame
{
    private JTextField txtCodigo, txtFechaInicio, txtFechaEntrega;
    private JTextField txtNombre, txtCedula, txtEmail, txtTelefono;
    private JTextField txtMarca, txtDireccion, txtModelo, txtPegatina;
    private JCheckBox chkSoporte;
    private JButton btnRegistrar, btnMultar;
    private JTextArea areaResultado;

    public JFAlquiler(){
        setTitle("Alquiler de Cámaras");
        setSize(700, 520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        crearInterfaz();
    }

    private void crearInterfaz(){
        JPanel principal = new JPanel(new BorderLayout(10, 10));
        principal.setBorder(new EmptyBorder(10, 15, 10, 15));

        // Formulario (datos de ejemplo ya escritos)
        JPanel form = new JPanel(new GridLayout(0, 4, 8, 6));
        form.setBorder(BorderFactory.createTitledBorder("Datos del alquiler"));

        txtCodigo = new JTextField("ALQ-001");
        txtFechaInicio = new JTextField("01/08/2026");
        txtFechaEntrega = new JTextField("15/08/2026");
        txtNombre = new JTextField("Juan Pérez");
        txtCedula = new JTextField("12345678");
        txtEmail = new JTextField("juan.perez@email.com");
        txtTelefono = new JTextField("555-0199");
        txtMarca = new JTextField("Canon");
        txtDireccion = new JTextField("Av. Principal 123");
        txtModelo = new JTextField("EOS R5");
        txtPegatina = new JTextField("1024");
        chkSoporte = new JCheckBox("Incluye soporte", true);

        agregar(form, "Código", txtCodigo);
        agregar(form, "Fecha inicio (dd/mm/aaaa)", txtFechaInicio);
        agregar(form, "Fecha entrega (dd/mm/aaaa)", txtFechaEntrega);
        agregar(form, "Cliente", txtNombre);
        agregar(form, "Cédula", txtCedula);
        agregar(form, "Email", txtEmail);
        agregar(form, "Teléfono", txtTelefono);
        agregar(form, "Marca", txtMarca);
        agregar(form, "Dirección marca", txtDireccion);
        agregar(form, "Modelo", txtModelo);
        agregar(form, "N° pegatina (item)", txtPegatina);
        form.add(new JLabel(""));
        form.add(chkSoporte);

        // Botones
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        btnRegistrar = new JButton("Registrar alquiler");
        btnMultar = new JButton("Evaluar multa");
        botones.add(btnRegistrar);
        botones.add(btnMultar);

        // Resultado
        areaResultado = new JTextArea();
        areaResultado.setEditable(false);
        areaResultado.setLineWrap(true);
        areaResultado.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(areaResultado);
        scroll.setBorder(BorderFactory.createTitledBorder("Resultado"));

        JPanel arriba = new JPanel(new BorderLayout());
        arriba.add(form, BorderLayout.CENTER);
        arriba.add(botones, BorderLayout.SOUTH);

        principal.add(arriba, BorderLayout.NORTH);
        principal.add(scroll, BorderLayout.CENTER);
        add(principal);
    }

    private void agregar(JPanel panel, String etiqueta, JTextField campo){
        panel.add(new JLabel(etiqueta));
        panel.add(campo);
    }

    // ---- Conexion con el controlador ----
    public void setControlador(ActionListener c){
        btnRegistrar.setActionCommand("REGISTRAR");
        btnRegistrar.addActionListener(c);
        btnMultar.setActionCommand("MULTAR");
        btnMultar.addActionListener(c);
    }

    // ---- Lo que el controlador lee de la vista ----
    public String getCodigo()       { return txtCodigo.getText().trim(); }
    public String getFechaInicio()  { return txtFechaInicio.getText().trim(); }
    public String getFechaEntrega() { return txtFechaEntrega.getText().trim(); }
    public String getNombre()       { return txtNombre.getText().trim(); }
    public String getCedula()       { return txtCedula.getText().trim(); }
    public String getEmail()        { return txtEmail.getText().trim(); }
    public String getTelefono()     { return txtTelefono.getText().trim(); }
    public String getMarca()        { return txtMarca.getText().trim(); }
    public String getDireccion()    { return txtDireccion.getText().trim(); }
    public String getModelo()       { return txtModelo.getText().trim(); }
    public String getPegatina()     { return txtPegatina.getText().trim(); }
    public boolean isSoporte()      { return chkSoporte.isSelected(); }

    public void mostrarResultado(String texto){
        areaResultado.setText(texto);
    }
}
