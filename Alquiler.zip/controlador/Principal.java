package controlador;

import vista.JFAlquiler;

public class Principal
{
    public static void main(String[] args){
        new Controlador(new JFAlquiler()).iniciar();
    }
}
