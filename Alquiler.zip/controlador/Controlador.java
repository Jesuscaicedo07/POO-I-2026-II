package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.DateTimeException;

import modelo.*;
import vista.JFAlquiler;

public class Controlador implements ActionListener
{
    private JFAlquiler vista;
    private Alquiler alquiler;     // null hasta que se registre uno
    private Item item;
    private Camara camara;

    public Controlador(JFAlquiler vista){
        this.vista = vista;
        vista.setControlador(this);
    }

    public void iniciar(){
        vista.setVisible(true);
    }

    public void actionPerformed(ActionEvent e){
        if (e.getActionCommand().equals("REGISTRAR")) {
            registrar();
        } else if (e.getActionCommand().equals("MULTAR")) {
            multar();
        }
    }

    private void registrar(){
        try {
            Fecha inicio = leerFecha(vista.getFechaInicio());
            Fecha entrega = leerFecha(vista.getFechaEntrega());
            int pegatina = Integer.parseInt(vista.getPegatina());

            Marca marca = new Marca(vista.getMarca(), vista.getDireccion());
            item = new Item(pegatina, Estado.ALQUILADO);
            Modelo modelo = new Modelo(vista.getModelo(), item);
            camara = new Camara(marca, modelo, vista.isSoporte());
            Cliente cliente = new Cliente(vista.getNombre(), vista.getCedula(),
                                          vista.getEmail(), vista.getTelefono(), false);

            alquiler = new Alquiler(vista.getCodigo(), inicio, entrega, cliente);
            alquiler.addItem(item);

            vista.mostrarResultado("Alquiler registrado"
                + "\nCódigo: " + alquiler.getCodigo()
                + "\nCliente: " + cliente.getNombre() + " (¿Bloqueado?: " + cliente.isBloqueado() + ")"
                + "\nCámara: " + marca.getNombre() + " " + modelo.getNombre()
                + "\nEstado del item: " + item.getEstado());
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException | DateTimeException ex) {
            vista.mostrarResultado("Datos no válidos. Revise las fechas (dd/mm/aaaa) y el número de pegatina.");
        }
    }

    private void multar(){
        if (alquiler == null) {
            vista.mostrarResultado("Primero registre un alquiler.");
            return;
        }
        String mensaje = alquiler.multar();
        vista.mostrarResultado(mensaje
            + "\n--------------------------------------------------"
            + "\nCliente: " + alquiler.getCliente().getNombre()
            + " (¿Bloqueado?: " + alquiler.getCliente().isBloqueado() + ")"
            + "\nEstado del item: " + item.getEstado());
    }

    /** Convierte "dd/mm/aaaa" en Fecha; lanza excepcion si no es valida. */
    private Fecha leerFecha(String texto){
        String[] p = texto.split("/");
        Fecha f = new Fecha(Integer.parseInt(p[0].trim()),
                            Integer.parseInt(p[1].trim()),
                            Integer.parseInt(p[2].trim()));
        f.toLocalDate();    // valida que la fecha exista
        return f;
    }
}
