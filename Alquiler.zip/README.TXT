Alquiler de Camaras - MVC (modelo, vista, controlador). Ejecutar controlador.Principal.
