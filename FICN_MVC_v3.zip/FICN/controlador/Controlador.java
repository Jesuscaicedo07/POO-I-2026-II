package controlador;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import modelo.*;

public class Controlador
{
    private ServicioConservacion servicio;
    private SimpleDateFormat formatoFecha;

    public Controlador(){
        servicio = new ServicioConservacion();
        formatoFecha = new SimpleDateFormat("yyyy-MM-dd");
        formatoFecha.setLenient(false);
    }

    // fechas
    public String formatearFecha(Date fecha){
        return formatoFecha.format(fecha);
    }

    public String fechaActual(){
        return formatoFecha.format(new Date());
    }

    public Date convertirFecha(String texto){
        try {
            return formatoFecha.parse(texto.trim());
        } catch (ParseException ex) {
            throw new IllegalArgumentException("La fecha debe tener el formato aaaa-mm-dd (ej. 2026-05-20).");
        }
    }

    // RF1: crear, modificar y buscar especies
    public void crearEspecie(String nombreComun, String nombreCientifico, ClasificacionBiologica clasificacion,
    CategoriaUICN categoria, FactorRiesgo factor){
        Especie nueva = new Especie(nombreComun, nombreCientifico, clasificacion, categoria, factor);
        servicio.crearEspecie(nueva);
    }

    public void modificarEspecie(Especie especie, String nombreComun, String nombreCientifico,
    ClasificacionBiologica clasificacion, CategoriaUICN categoria, FactorRiesgo factor){
        if (especie == null) {
            throw new IllegalArgumentException("Seleccione una especie para modificarla.");
        }
        String comunAntes = especie.getNombreComun();
        String cientificoAntes = especie.getNombreCientifico();
        ClasificacionBiologica clasificacionAntes = especie.getClasificacion();
        CategoriaUICN categoriaAntes = especie.getCategoriaUICN();
        FactorRiesgo factorAntes = especie.getFactorRiesgoPrincipal();
        try {
            especie.setNombreComun(nombreComun);
            especie.setNombreCientifico(nombreCientifico);
            especie.setClasificacion(clasificacion);
            especie.setCategoriaUICN(categoria);
            especie.setFactorRiesgoPrincipal(factor);
            servicio.actualizarEspecie(especie);
        } catch (IllegalArgumentException ex) {
            especie.setNombreComun(comunAntes);
            especie.setNombreCientifico(cientificoAntes);
            especie.setClasificacion(clasificacionAntes);
            especie.setCategoriaUICN(categoriaAntes);
            especie.setFactorRiesgoPrincipal(factorAntes);
            throw ex;
        }
    }

    public ArrayList<Especie> buscarEspecie(String criterio){
        return servicio.buscarEspecie(criterio);
    }

    public ArrayList<Especie> getEspecies(){
        return servicio.getEspecies();
    }

    // Ecosistemas y RF2: asignar especies a ecosistemas
    public void crearEcosistema(String nombre, String ubicacion, NivelAfectacion nivel){
        servicio.agregarEcosistema(new Ecosistema(nombre, ubicacion, nivel));
    }

    public ArrayList<Ecosistema> getEcosistemas(){
        return servicio.getEcosistemas();
    }

    public void asignarEspecieAEcosistema(Especie e, Ecosistema eco){
        servicio.asignarEspecieAEcosistema(e, eco);
    }

    // RF3: amenazas por ecosistema
    public void registrarAmenaza(Ecosistema eco, String descripcion, FactorRiesgo factor, String fecha,
    String investigador, Especie especieAfectada){
        Amenaza nueva = new Amenaza(descripcion, factor, convertirFecha(fecha), investigador);
        nueva.setEspecieAfectada(especieAfectada);
        servicio.registrarAmenaza(eco, nueva);
    }

    public void marcarAmenazaGrave(Amenaza a){
        servicio.marcarAmenazaGrave(a);
    }

    // RF4: censos
    public void registrarCenso(Especie e, String fecha, String poblacion){
        Date fechaCenso = convertirFecha(fecha);
        int cantidad;
        try {
            cantidad = Integer.parseInt(poblacion.trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("La población debe ser un número entero.");
        }
        servicio.registrarCenso(e, new Censo(fechaCenso, cantidad));
    }

    // devuelve {población actual, variación, tasa de declive, aviso}
    public String[] getResumenCensos(Especie especie){
        String[] resumen = new String[]{"-", "-", "-", " "};
        if (especie == null) {
            return resumen;
        }
        if (especie.getCensos().isEmpty()) {
            resumen[3] = "Esta especie aún no tiene censos registrados.";
            return resumen;
        }
        resumen[0] = String.format("%,d individuos", especie.getPoblacionActual());
        if (!especie.tieneCensosSuficientes()) {
            resumen[3] = "Se necesitan al menos dos censos para calcular la variación.";
            return resumen;
        }
        try {
            resumen[1] = String.format("%+.2f %%", especie.calcularVariacion());
            double tasa = especie.calcularTasaDeclive();
            if (tasa > 0) {
                resumen[2] = String.format("%.2f %% por año", tasa);
            } else {
                resumen[2] = "Sin declive (la población no disminuyó)";
            }
        } catch (IllegalStateException ex) {
            resumen[3] = ex.getMessage();
        }
        return resumen;
    }

    // RF5: especies críticas de un ecosistema
    public ArrayList<Especie> filtrarCriticas(Ecosistema eco){
        return servicio.filtrarCriticas(eco);
    }

    // RF6: reporte de prioridad
    public ReportePrioridad generarReportePrioridad(String presupuesto){
        double valor;
        try {
            valor = Double.parseDouble(presupuesto.trim().replace("$", "").replace(" ", ""));
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("El presupuesto debe ser un número (ej. 1500000).");
        }
        return generarReportePrioridad(valor);
    }

    public ReportePrioridad generarReportePrioridad(double presupuesto){
        if (presupuesto <= 0) {
            throw new IllegalArgumentException("El presupuesto debe ser mayor que cero.");
        }
        return servicio.generarReportePrioridad(presupuesto);
    }

    public String getAvisoReporte(ReportePrioridad reporte){
        ArrayList<ItemRanking> ranking = reporte.getRankingUrgencia();
        if (ranking.isEmpty()) {
            return "Ninguna especie tiene al menos dos censos; no hay ranking que mostrar.";
        }
        String aviso = String.format("Presupuesto: %,.2f. ", reporte.getPresupuestoDisponible());
        if (ranking.get(0).getTasaDeclive() <= 0) {
            aviso += "Ninguna especie del ranking presenta declive. ";
        }
        int excluidas = servicio.getEspecies().size() - ranking.size();
        if (excluidas > 0) {
            aviso += excluidas + " especie(s) quedaron fuera por no tener censos suficientes.";
        }
        return aviso;
    }

    public void exportarReporte(ReportePrioridad reporte, File archivo) throws IOException{
        if (reporte == null) {
            throw new IllegalArgumentException("Primero genere el reporte.");
        }
        try (FileWriter escritor = new FileWriter(archivo)) {
            escritor.write(reporte.exportar());
        }
    }

    // datos de prueba
    private Date fecha(int anio, int mes, int dia){
        return new GregorianCalendar(anio, mes - 1, dia).getTime();
    }

    public void cargarDatosEjemplo(){
        Especie pinguino = new Especie("Pingüino emperador", "Aptenodytes forsteri",
            ClasificacionBiologica.AVE, CategoriaUICN.EN_PELIGRO, FactorRiesgo.CAMBIO_CLIMATICO);
        Especie ajolote = new Especie("Ajolote", "Ambystoma mexicanum",
            ClasificacionBiologica.ANFIBIO, CategoriaUICN.EN_PELIGRO_CRITICO, FactorRiesgo.CONTAMINACION);
        Especie lobo = new Especie("Lobo fino antártico", "Arctocephalus gazella",
            ClasificacionBiologica.MAMIFERO, CategoriaUICN.EN_PELIGRO, FactorRiesgo.CAMBIO_CLIMATICO);
        servicio.crearEspecie(pinguino);
        servicio.crearEspecie(ajolote);
        servicio.crearEspecie(lobo);

        servicio.registrarCenso(pinguino, new Censo(fecha(2009, 1, 1), 250000));
        servicio.registrarCenso(pinguino, new Censo(fecha(2018, 1, 1), 230000));
        servicio.registrarCenso(ajolote, new Censo(fecha(1998, 1, 1), 6000));
        servicio.registrarCenso(ajolote, new Censo(fecha(2024, 1, 1), 36));
        servicio.registrarCenso(lobo, new Censo(fecha(1999, 1, 1), 2187000));
        servicio.registrarCenso(lobo, new Censo(fecha(2025, 1, 1), 944000));

        Ecosistema antartida = new Ecosistema("Antártida", "Polo Sur", NivelAfectacion.ALTO);
        Ecosistema xochimilco = new Ecosistema("Canales de Xochimilco", "Ciudad de México", NivelAfectacion.CRITICO);
        servicio.agregarEcosistema(antartida);
        servicio.agregarEcosistema(xochimilco);
        servicio.asignarEspecieAEcosistema(pinguino, antartida);
        servicio.asignarEspecieAEcosistema(lobo, antartida);
        servicio.asignarEspecieAEcosistema(ajolote, xochimilco);

        Amenaza hielo = new Amenaza("Ruptura temprana del hielo marino", FactorRiesgo.CAMBIO_CLIMATICO,
            fecha(2026, 4, 10), "Equipo Antártida");
        hielo.setEspecieAfectada(pinguino);
        servicio.registrarAmenaza(antartida, hielo);
        servicio.marcarAmenazaGrave(hielo);
        servicio.registrarAmenaza(xochimilco, new Amenaza("Contaminación del agua de los canales",
            FactorRiesgo.CONTAMINACION, fecha(2026, 5, 14), "Equipo Xochimilco"));
    }
}
