package modelo;

import java.util.ArrayList;

public class Ecosistema
{
    private String nombre;
    private String ubicacion;
    private NivelAfectacion nivelAfectacion;
    private ArrayList<Especie> especies;
    private ArrayList<Amenaza> amenazas;

    public Ecosistema(String nombre, String ubicacion, NivelAfectacion nivelAfectacion){
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del ecosistema es obligatorio.");
        }
        if (ubicacion == null || ubicacion.trim().isEmpty()) {
            throw new IllegalArgumentException("La ubicación es obligatoria.");
        }
        if (nivelAfectacion == null) {
            throw new IllegalArgumentException("Debe seleccionar el nivel de afectación.");
        }
        this.nombre = nombre.trim();
        this.ubicacion = ubicacion.trim();
        this.nivelAfectacion = nivelAfectacion;
        this.especies = new ArrayList<Especie>();
        this.amenazas = new ArrayList<Amenaza>();
    }

    public String getNombre(){
        return nombre;
    }

    public String getUbicacion(){
        return ubicacion;
    }

    public NivelAfectacion getNivelAfectacion(){
        return nivelAfectacion;
    }

    public ArrayList<Especie> getEspecies(){
        return especies;
    }

    public boolean contieneEspecie(Especie e){
        return especies.contains(e);
    }

    public void agregarEspecie(Especie e){
        if (e != null && !especies.contains(e)) {
            especies.add(e);
        }
    }

    public ArrayList<Amenaza> getAmenazas(){
        return amenazas;
    }

    public void agregarAmenaza(Amenaza a){
        if (a == null) {
            throw new IllegalArgumentException("La amenaza es obligatoria.");
        }
        amenazas.add(a);
    }

    public ArrayList<Amenaza> getAmenazasGraves(){
        ArrayList<Amenaza> graves = new ArrayList<Amenaza>();
        for (Amenaza a : amenazas) {
            if (a.esGrave()) {
                graves.add(a);
            }
        }
        return graves;
    }

    public ArrayList<Especie> getEspeciesCriticas(){
        ArrayList<Especie> criticas = new ArrayList<Especie>();
        for (Especie e : especies) {
            if (e.esCritica()) {
                criticas.add(e);
            }
        }
        return criticas;
    }

    public String toString(){
        return nombre;
    }
}
