package modelo;

import java.util.ArrayList;
import java.util.Collections;

public class Especie
{
    private String nombreComun;
    private String nombreCientifico;
    private ClasificacionBiologica clasificacion;
    private CategoriaUICN categoriaUICN;
    private FactorRiesgo factorRiesgoPrincipal;
    private ArrayList<Censo> censos;

    public Especie(String nombreComun, String nombreCientifico, ClasificacionBiologica clasificacion,
    CategoriaUICN categoriaUICN, FactorRiesgo factorRiesgoPrincipal){
        setNombreComun(nombreComun);
        setNombreCientifico(nombreCientifico);
        setClasificacion(clasificacion);
        setCategoriaUICN(categoriaUICN);
        setFactorRiesgoPrincipal(factorRiesgoPrincipal);
        this.censos = new ArrayList<Censo>();
    }

    public String getNombreComun(){
        return nombreComun;
    }

    public void setNombreComun(String nombreComun){
        if (nombreComun == null || nombreComun.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre común es obligatorio.");
        }
        this.nombreComun = nombreComun.trim();
    }

    public String getNombreCientifico(){
        return nombreCientifico;
    }

    public void setNombreCientifico(String nombreCientifico){
        if (nombreCientifico == null || nombreCientifico.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre científico es obligatorio.");
        }
        this.nombreCientifico = nombreCientifico.trim();
    }

    public ClasificacionBiologica getClasificacion(){
        return clasificacion;
    }

    public void setClasificacion(ClasificacionBiologica clasificacion){
        if (clasificacion == null) {
            throw new IllegalArgumentException("Seleccione la clasificación biológica.");
        }
        this.clasificacion = clasificacion;
    }

    public CategoriaUICN getCategoriaUICN(){
        return categoriaUICN;
    }

    public void setCategoriaUICN(CategoriaUICN categoriaUICN){
        if (categoriaUICN == null) {
            throw new IllegalArgumentException("Seleccione la categoría UICN.");
        }
        this.categoriaUICN = categoriaUICN;
    }

    public FactorRiesgo getFactorRiesgoPrincipal(){
        return factorRiesgoPrincipal;
    }

    public void setFactorRiesgoPrincipal(FactorRiesgo factorRiesgoPrincipal){
        if (factorRiesgoPrincipal == null) {
            throw new IllegalArgumentException("Seleccione el factor de riesgo principal.");
        }
        this.factorRiesgoPrincipal = factorRiesgoPrincipal;
    }

    public ArrayList<Censo> getCensos(){
        return censos;
    }

    public void agregarCenso(Censo c){
        if (c == null) {
            throw new IllegalArgumentException("El censo es obligatorio.");
        }
        censos.add(c);
        Collections.sort(censos);
    }

    public Censo getUltimoCenso(){
        if (censos.isEmpty()) {
            return null;
        }
        return censos.get(censos.size() - 1);
    }

    public int getPoblacionActual(){
        Censo ultimo = getUltimoCenso();
        if (ultimo == null) {
            return 0;
        }
        return ultimo.getPoblacion();
    }

    public boolean tieneCensosSuficientes(){
        return censos.size() >= 2;
    }

    public double calcularVariacion(){
        if (!tieneCensosSuficientes()) {
            throw new IllegalStateException("Se necesitan al menos dos censos.");
        }
        Censo anterior = censos.get(censos.size() - 2);
        return getUltimoCenso().variacionRespecto(anterior);
    }

    public double calcularTasaDeclive(){
        double variacion = calcularVariacion();
        Censo anterior = censos.get(censos.size() - 2);
        double anios = getUltimoCenso().aniosDesde(anterior);
        if (anios <= 0) {
            throw new IllegalStateException("Los dos últimos censos tienen la misma fecha.");
        }
        return -variacion / anios;
    }

    public boolean esCritica(){
        return categoriaUICN == CategoriaUICN.EN_PELIGRO_CRITICO;
    }

    public String toString(){
        return nombreComun + " (" + nombreCientifico + ")";
    }
}
