package modelo;

import java.util.Date;

public class Amenaza
{
    private String descripcion;
    private FactorRiesgo factor;
    private Date fechaObservacion;
    private String investigador;
    private boolean grave;
    private Especie especieAfectada;

    public Amenaza(String descripcion, FactorRiesgo factor, Date fechaObservacion, String investigador){
        if (descripcion == null || descripcion.trim().isEmpty()) {
            throw new IllegalArgumentException("La descripción es obligatoria.");
        }
        if (factor == null) {
            throw new IllegalArgumentException("Seleccione el factor de riesgo.");
        }
        if (fechaObservacion == null) {
            throw new IllegalArgumentException("La fecha de observación es obligatoria.");
        }
        if (investigador == null || investigador.trim().isEmpty()) {
            throw new IllegalArgumentException("El investigador es obligatorio.");
        }
        this.descripcion = descripcion.trim();
        this.factor = factor;
        this.fechaObservacion = fechaObservacion;
        this.investigador = investigador.trim();
        this.grave = false;
    }

    public String getDescripcion(){
        return descripcion;
    }

    public FactorRiesgo getFactor(){
        return factor;
    }

    public Date getFechaObservacion(){
        return fechaObservacion;
    }

    public String getInvestigador(){
        return investigador;
    }

    public boolean esGrave(){
        return grave;
    }

    public void marcarGrave(){
        this.grave = true;
    }

    public Especie getEspecieAfectada(){
        return especieAfectada;
    }

    public void setEspecieAfectada(Especie especieAfectada){
        this.especieAfectada = especieAfectada;
    }
}
