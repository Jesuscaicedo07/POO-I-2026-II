package modelo;

import java.util.ArrayList;
import java.util.Date;

public class ServicioConservacion
{
    private ArrayList<Ecosistema> ecosistemas;
    private ArrayList<Especie> especies;

    public ServicioConservacion(){
        ecosistemas = new ArrayList<Ecosistema>();
        especies = new ArrayList<Especie>();
    }

    public void crearEspecie(Especie e){
        if (e == null) {
            throw new IllegalArgumentException("La especie es obligatoria.");
        }
        if (existeOtraConCientifico(e)) {
            throw new IllegalArgumentException("Ya existe una especie con ese nombre científico.");
        }
        especies.add(e);
    }

    public void actualizarEspecie(Especie e){
        if (e == null || !especies.contains(e)) {
            throw new IllegalArgumentException("La especie no está en el catálogo.");
        }
        if (existeOtraConCientifico(e)) {
            throw new IllegalArgumentException("Ya existe otra especie con ese nombre científico.");
        }
    }

    public ArrayList<Especie> buscarEspecie(String criterio){
        ArrayList<Especie> resultado = new ArrayList<Especie>();
        String texto = "";
        if (criterio != null) {
            texto = criterio.trim().toLowerCase();
        }
        for (int i = 0; i < especies.size(); i++) {
            Especie e = especies.get(i);
            if (texto.isEmpty()
                || e.getNombreComun().toLowerCase().contains(texto)
                || e.getNombreCientifico().toLowerCase().contains(texto)
                || e.getClasificacion().toString().toLowerCase().contains(texto)
                || e.getCategoriaUICN().toString().toLowerCase().contains(texto)) {
                resultado.add(e);
            }
        }
        return resultado;
    }

    private boolean existeOtraConCientifico(Especie e){
        for (int i = 0; i < especies.size(); i++) {
            Especie otra = especies.get(i);
            if (otra != e && otra.getNombreCientifico().equalsIgnoreCase(e.getNombreCientifico())) {
                return true;
            }
        }
        return false;
    }

    public ArrayList<Especie> getEspecies(){
        return especies;
    }

    public void agregarEcosistema(Ecosistema eco){
        if (eco == null) {
            throw new IllegalArgumentException("El ecosistema es obligatorio.");
        }
        for (int i = 0; i < ecosistemas.size(); i++) {
            if (ecosistemas.get(i).getNombre().equalsIgnoreCase(eco.getNombre())) {
                throw new IllegalArgumentException("Ya existe un ecosistema con ese nombre.");
            }
        }
        ecosistemas.add(eco);
    }

    public ArrayList<Ecosistema> getEcosistemas(){
        return ecosistemas;
    }

    public void asignarEspecieAEcosistema(Especie e, Ecosistema eco){
        if (e == null || eco == null) {
            throw new IllegalArgumentException("Seleccione un ecosistema y una especie.");
        }
        if (eco.contieneEspecie(e)) {
            throw new IllegalArgumentException("Esa especie ya está asignada a este ecosistema.");
        }
        eco.agregarEspecie(e);
    }

    public void registrarAmenaza(Ecosistema eco, Amenaza a){
        if (eco == null) {
            throw new IllegalArgumentException("Seleccione un ecosistema.");
        }
        eco.agregarAmenaza(a);
    }

    public void marcarAmenazaGrave(Amenaza a){
        if (a == null) {
            throw new IllegalArgumentException("Seleccione una amenaza.");
        }
        a.marcarGrave();
    }

    public void registrarCenso(Especie e, Censo c){
        if (e == null) {
            throw new IllegalArgumentException("Seleccione una especie.");
        }
        if (c == null) {
            throw new IllegalArgumentException("El censo es obligatorio.");
        }
        ArrayList<Censo> censos = e.getCensos();
        for (int i = 0; i < censos.size(); i++) {
            if (censos.get(i).getFecha().equals(c.getFecha())) {
                throw new IllegalArgumentException("Ya existe un censo en esa fecha para la especie.");
            }
        }
        e.agregarCenso(c);
    }

    public ArrayList<Especie> filtrarCriticas(Ecosistema eco){
        if (eco == null) {
            throw new IllegalArgumentException("Seleccione un ecosistema.");
        }
        return eco.getEspeciesCriticas();
    }

    public ReportePrioridad generarReportePrioridad(double presupuesto){
        ArrayList<ItemRanking> items = new ArrayList<ItemRanking>();
        for (int i = 0; i < especies.size(); i++) {
            Especie e = especies.get(i);
            if (e.tieneCensosSuficientes()) {
                try {
                    items.add(new ItemRanking(e, e.calcularVariacion(), e.calcularTasaDeclive()));
                } catch (IllegalStateException ex) {
                    System.out.println("No se pudo calcular: " + e.getNombreComun());
                }
            }
        }
        return new ReportePrioridad(new Date(), presupuesto, items);
    }
}
