package modelo;

public class ItemRanking implements Comparable<ItemRanking>
{
    private int posicion;
    private double variacionPorcentual;
    private double tasaDeclive;
    private Especie especie;

    public ItemRanking(Especie especie, double variacionPorcentual, double tasaDeclive){
        this.especie = especie;
        this.variacionPorcentual = variacionPorcentual;
        this.tasaDeclive = tasaDeclive;
    }

    public int getPosicion(){
        return posicion;
    }

    public void setPosicion(int posicion){
        this.posicion = posicion;
    }

    public double getVariacionPorcentual(){
        return variacionPorcentual;
    }

    public double getTasaDeclive(){
        return tasaDeclive;
    }

    public Especie getEspecie(){
        return especie;
    }

    public int compareTo(ItemRanking otro){
        int resultado = Double.compare(otro.getTasaDeclive(), this.tasaDeclive);
        if (resultado != 0) {
            return resultado;
        }
        resultado = Integer.compare(otro.getEspecie().getCategoriaUICN().getNivel(),
                                    this.especie.getCategoriaUICN().getNivel());
        if (resultado != 0) {
            return resultado;
        }
        return Integer.compare(this.especie.getPoblacionActual(), otro.getEspecie().getPoblacionActual());
    }
}
