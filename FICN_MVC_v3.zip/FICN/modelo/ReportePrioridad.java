package modelo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class ReportePrioridad
{
    private Date fechaGeneracion;
    private double presupuestoDisponible;
    private ArrayList<ItemRanking> ranking;

    public ReportePrioridad(Date fechaGeneracion, double presupuestoDisponible, ArrayList<ItemRanking> ranking){
        this.fechaGeneracion = fechaGeneracion;
        this.presupuestoDisponible = presupuestoDisponible;
        this.ranking = new ArrayList<ItemRanking>(ranking);
        Collections.sort(this.ranking);
        for (int i = 0; i < this.ranking.size(); i++) {
            this.ranking.get(i).setPosicion(i + 1);
        }
    }

    public Date getFechaGeneracion(){
        return fechaGeneracion;
    }

    public double getPresupuestoDisponible(){
        return presupuestoDisponible;
    }

    public Especie getEspeciePrioritaria(){
        if (ranking.isEmpty()) {
            return null;
        }
        return ranking.get(0).getEspecie();
    }

    public ArrayList<ItemRanking> getRankingUrgencia(){
        return ranking;
    }

    public String exportar(){
        SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd");
        String texto = "REPORTE DE PRIORIDAD - FICN\n";
        texto += "Fecha: " + formato.format(fechaGeneracion) + "\n";
        texto += String.format("Presupuesto disponible: %,.2f%n", presupuestoDisponible);
        for (int i = 0; i < ranking.size(); i++) {
            ItemRanking item = ranking.get(i);
            texto += String.format("%d. %s | variación %.2f %% | declive anual %.2f %%%n",
                item.getPosicion(), item.getEspecie(), item.getVariacionPorcentual(), item.getTasaDeclive());
        }
        return texto;
    }
}
