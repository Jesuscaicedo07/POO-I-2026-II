package modelo;

public enum ClasificacionBiologica
{
    MAMIFERO("Mamífero"),
    AVE("Ave"),
    ANFIBIO("Anfibio"),
    REPTIL("Reptil"),
    PEZ("Pez"),
    INVERTEBRADO("Invertebrado");

    private String etiqueta;

    ClasificacionBiologica(String etiqueta){
        this.etiqueta = etiqueta;
    }

    public String toString(){
        return etiqueta;
    }
}
