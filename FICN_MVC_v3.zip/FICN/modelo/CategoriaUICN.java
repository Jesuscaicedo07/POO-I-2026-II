package modelo;

public enum CategoriaUICN
{
    PREOCUPACION_MENOR("Preocupación Menor"),
    CASI_AMENAZADA("Casi Amenazada"),
    VULNERABLE("Vulnerable"),
    EN_PELIGRO("En Peligro"),
    EN_PELIGRO_CRITICO("En Peligro Crítico");

    private String etiqueta;

    CategoriaUICN(String etiqueta){
        this.etiqueta = etiqueta;
    }

    public int getNivel(){
        return ordinal() + 1;
    }

    public String toString(){
        return etiqueta;
    }
}
