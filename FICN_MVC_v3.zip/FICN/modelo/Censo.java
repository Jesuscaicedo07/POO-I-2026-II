package modelo;

import java.util.Date;

public class Censo implements Comparable<Censo>
{
    private static final double MILISEGUNDOS_ANIO = 365.25 * 24 * 60 * 60 * 1000;

    private Date fecha;
    private int poblacion;

    public Censo(Date fecha, int poblacion){
        if (fecha == null) {
            throw new IllegalArgumentException("La fecha del censo es obligatoria.");
        }
        if (poblacion < 0) {
            throw new IllegalArgumentException("La población no puede ser negativa.");
        }
        this.fecha = fecha;
        this.poblacion = poblacion;
    }

    public Date getFecha(){
        return fecha;
    }

    public int getPoblacion(){
        return poblacion;
    }

    public double variacionRespecto(Censo anterior){
        if (anterior.getPoblacion() == 0) {
            throw new IllegalStateException("El censo anterior es 0; no se puede calcular el porcentaje.");
        }
        return (this.poblacion - anterior.getPoblacion()) * 100.0 / anterior.getPoblacion();
    }

    public double aniosDesde(Censo anterior){
        return (this.fecha.getTime() - anterior.getFecha().getTime()) / MILISEGUNDOS_ANIO;
    }

    public int compareTo(Censo otro){
        return this.fecha.compareTo(otro.getFecha());
    }
}
