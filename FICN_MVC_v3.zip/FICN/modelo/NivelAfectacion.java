package modelo;

public enum NivelAfectacion
{
    BAJO("Bajo"),
    MEDIO("Medio"),
    ALTO("Alto"),
    CRITICO("Crítico");

    private String etiqueta;

    NivelAfectacion(String etiqueta){
        this.etiqueta = etiqueta;
    }

    public String toString(){
        return etiqueta;
    }
}
