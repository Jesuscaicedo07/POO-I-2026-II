package modelo;

public enum FactorRiesgo
{
    PERDIDA_HABITAT("Pérdida de hábitat"),
    CAMBIO_CLIMATICO("Cambio climático"),
    CAZA("Caza"),
    CONTAMINACION("Contaminación"),
    OTRO("Otro");

    private String etiqueta;

    FactorRiesgo(String etiqueta){
        this.etiqueta = etiqueta;
    }

    public String toString(){
        return etiqueta;
    }
}
