package vista;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import controlador.Controlador;

public class FrmPrincipal extends JFrame
{
    private PnlEspecies pnlEspecies;
    private PnlEcosistemas pnlEcosistemas;
    private PnlCensos pnlCensos;
    private PnlAmenazas pnlAmenazas;
    private PnlCriticas pnlCriticas;
    private PnlReporte pnlReporte;

    public FrmPrincipal(Controlador control){
        setTitle("FICN - Plataforma de Conservación de Especies en Peligro");

        pnlEspecies = new PnlEspecies(control, this);
        pnlEcosistemas = new PnlEcosistemas(control);
        pnlCensos = new PnlCensos(control);
        pnlAmenazas = new PnlAmenazas(control);
        pnlCriticas = new PnlCriticas(control);
        pnlReporte = new PnlReporte(control);

        JLabel titulo = new JLabel("Plataforma de Conservación de Especies en Peligro", SwingConstants.CENTER);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 20f));
        titulo.setForeground(Color.WHITE);

        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(new Color(34, 99, 71));
        encabezado.setBorder(BorderFactory.createEmptyBorder(12, 10, 12, 10));
        encabezado.add(titulo, BorderLayout.CENTER);

        JTabbedPane pestanas = new JTabbedPane();
        pestanas.addTab("Especies", pnlEspecies);
        pestanas.addTab("Ecosistemas", pnlEcosistemas);
        pestanas.addTab("Amenazas", pnlAmenazas);
        pestanas.addTab("Censos", pnlCensos);
        pestanas.addTab("Especies críticas", pnlCriticas);
        pestanas.addTab("Reporte de prioridad", pnlReporte);
        pestanas.addChangeListener(new ChangeListener()
        {
            public void stateChanged(ChangeEvent e){
                especiesCambiaron();
            }
        });

        setLayout(new BorderLayout());
        add(encabezado, BorderLayout.NORTH);
        add(pestanas, BorderLayout.CENTER);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(900, 560));
        setSize(980, 620);
        setLocationRelativeTo(null);
    }

    public void especiesCambiaron(){
        pnlEcosistemas.refrescar();
        pnlAmenazas.refrescar();
        pnlCensos.refrescar();
        pnlCriticas.refrescar();
        pnlReporte.refrescar();
    }
}
