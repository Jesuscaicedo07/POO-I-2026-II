package vista;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import controlador.Controlador;
import modelo.*;

public class PnlCensos extends JPanel implements ActionListener
{
    private Controlador control;

    private JComboBox<Especie> comboEspecie;
    private JTextField txtFecha, txtCantidad;
    private JButton btnRegistrar;
    private DefaultTableModel modeloTabla;
    private JTable tabla;
    private JLabel lblActual, lblVariacion, lblTasa, lblAviso;

    public PnlCensos(Controlador control){
        this.control = control;
        crearInterfaz();
        refrescar();
    }

    private void crearInterfaz(){
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        comboEspecie = new JComboBox<Especie>();
        txtFecha = new JTextField(10);
        txtCantidad = new JTextField(10);
        btnRegistrar = new JButton("Registrar censo");
        lblActual = new JLabel("-");
        lblVariacion = new JLabel("-");
        lblTasa = new JLabel("-");
        lblAviso = new JLabel(" ");

        JPanel registro = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        registro.setBorder(BorderFactory.createTitledBorder("Registrar censo"));
        txtFecha.setText(control.fechaActual());
        registro.add(new JLabel("Especie:"));
        registro.add(comboEspecie);
        registro.add(new JLabel("Fecha (aaaa-mm-dd):"));
        registro.add(txtFecha);
        registro.add(new JLabel("Población:"));
        registro.add(txtCantidad);
        registro.add(btnRegistrar);
        add(registro, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new String[]{"Fecha", "Población"}, 0)
        {
            public boolean isCellEditable(int fila, int columna){
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setRowHeight(22);

        JPanel historial = new JPanel(new BorderLayout());
        historial.setBorder(BorderFactory.createTitledBorder("Historial de censos de la especie"));
        historial.add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(historial, BorderLayout.CENTER);

        JPanel resultados = new JPanel(new BorderLayout(0, 4));
        resultados.setBorder(BorderFactory.createTitledBorder("Variación de la población"));
        JPanel cifras = new JPanel(new GridLayout(3, 2, 6, 4));
        cifras.add(new JLabel("Población actual (censo más reciente):"));
        cifras.add(lblActual);
        cifras.add(new JLabel("Variación porcentual entre los dos últimos censos:"));
        cifras.add(lblVariacion);
        cifras.add(new JLabel("Tasa de declive anual:"));
        cifras.add(lblTasa);

        Font negrita = lblActual.getFont().deriveFont(Font.BOLD);
        lblActual.setFont(negrita);
        lblVariacion.setFont(negrita);
        lblTasa.setFont(negrita);

        resultados.add(cifras, BorderLayout.CENTER);
        resultados.add(lblAviso, BorderLayout.SOUTH);
        add(resultados, BorderLayout.SOUTH);

        btnRegistrar.addActionListener(this);
        comboEspecie.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){
        Object origen = e.getSource();

        if (origen == btnRegistrar) {
            registrar();
        } else if (origen == comboEspecie) {
            mostrarEspecie();
        }
    }

    private void registrar(){
        Especie especie = (Especie) comboEspecie.getSelectedItem();
        try {
            control.registrarCenso(especie, txtFecha.getText(), txtCantidad.getText());
            txtCantidad.setText("");
            mostrarEspecie();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos inválidos",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void mostrarEspecie(){
        modeloTabla.setRowCount(0);
        Especie especie = (Especie) comboEspecie.getSelectedItem();
        if (especie != null) {
            ArrayList<Censo> censos = especie.getCensos();
            for (int i = 0; i < censos.size(); i++) {
                Censo c = censos.get(i);
                modeloTabla.addRow(new Object[]{control.formatearFecha(c.getFecha()), c.getPoblacion()});
            }
        }
        String[] resumen = control.getResumenCensos(especie);
        lblActual.setText(resumen[0]);
        lblVariacion.setText(resumen[1]);
        lblTasa.setText(resumen[2]);
        lblAviso.setText(resumen[3]);
    }

    public void refrescar(){
        Object seleccionada = comboEspecie.getSelectedItem();
        comboEspecie.removeAllItems();
        ArrayList<Especie> especies = control.getEspecies();
        for (int i = 0; i < especies.size(); i++) {
            comboEspecie.addItem(especies.get(i));
        }
        if (seleccionada != null) {
            comboEspecie.setSelectedItem(seleccionada);
        }
        mostrarEspecie();
    }
}
