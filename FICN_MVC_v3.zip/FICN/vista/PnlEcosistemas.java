package vista;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import controlador.Controlador;
import modelo.*;

public class PnlEcosistemas extends JPanel implements ActionListener
{
    private Controlador control;
    private ArrayList<Ecosistema> ecosistemas;

    private JTextField txtNombre, txtUbicacion;
    private JComboBox<NivelAfectacion> comboNivel;
    private JComboBox<Ecosistema> comboEcosistema;
    private JComboBox<Especie> comboEspecie;
    private JButton btnCrear, btnAsignar;
    private JLabel lblEspeciesDe;
    private DefaultTableModel modeloTabla;
    private JTable tabla;
    private DefaultListModel<Especie> modeloLista;
    private JList<Especie> listaEspecies;

    public PnlEcosistemas(Controlador control){
        this.control = control;
        crearInterfaz();
        refrescar();
    }

    private void crearInterfaz(){
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtNombre = new JTextField(16);
        txtUbicacion = new JTextField(16);
        comboNivel = new JComboBox<NivelAfectacion>(NivelAfectacion.values());
        comboEcosistema = new JComboBox<Ecosistema>();
        comboEspecie = new JComboBox<Especie>();
        btnCrear = new JButton("Crear ecosistema");
        btnAsignar = new JButton("Asignar");
        lblEspeciesDe = new JLabel("Especies del ecosistema seleccionado");

        JPanel crear = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        crear.setBorder(BorderFactory.createTitledBorder("Nuevo ecosistema"));
        crear.add(new JLabel("Nombre:"));
        crear.add(txtNombre);
        crear.add(new JLabel("Ubicación:"));
        crear.add(txtUbicacion);
        crear.add(new JLabel("Nivel:"));
        crear.add(comboNivel);
        crear.add(btnCrear);
        add(crear, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(
            new String[]{"Ecosistema", "Ubicación", "Nivel de afectación", "N.º de especies"}, 0)
        {
            public boolean isCellEditable(int fila, int columna){
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(22);

        JPanel izquierda = new JPanel(new BorderLayout());
        izquierda.setBorder(BorderFactory.createTitledBorder("Ecosistemas"));
        izquierda.add(new JScrollPane(tabla), BorderLayout.CENTER);

        modeloLista = new DefaultListModel<Especie>();
        listaEspecies = new JList<Especie>(modeloLista);

        JPanel derecha = new JPanel(new BorderLayout(0, 4));
        derecha.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        derecha.add(lblEspeciesDe, BorderLayout.NORTH);
        derecha.add(new JScrollPane(listaEspecies), BorderLayout.CENTER);

        JSplitPane division = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, izquierda, derecha);
        division.setResizeWeight(0.62);
        add(division, BorderLayout.CENTER);

        JPanel asignar = new JPanel(new GridBagLayout());
        asignar.setBorder(BorderFactory.createTitledBorder("Asignar especie a un ecosistema"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.gridy = 0;
        g.gridx = 0;
        g.weightx = 0;
        asignar.add(new JLabel("Ecosistema:"), g);
        g.gridx = 1;
        g.weightx = 1;
        asignar.add(comboEcosistema, g);
        g.gridx = 2;
        g.weightx = 0;
        asignar.add(new JLabel("Especie:"), g);
        g.gridx = 3;
        g.weightx = 1;
        asignar.add(comboEspecie, g);
        g.gridx = 4;
        g.weightx = 0;
        asignar.add(btnAsignar, g);
        add(asignar, BorderLayout.SOUTH);

        btnCrear.addActionListener(this);
        btnAsignar.addActionListener(this);
        tabla.getSelectionModel().addListSelectionListener(new ListSelectionListener()
        {
            public void valueChanged(ListSelectionEvent e){
                if (!e.getValueIsAdjusting()) {
                    mostrarEspecies();
                }
            }
        });
    }

    public void actionPerformed(ActionEvent e){
        Object origen = e.getSource();

        if (origen == btnCrear) {
            crearEcosistema();
        } else if (origen == btnAsignar) {
            asignar();
        }
    }

    private void crearEcosistema(){
        try {
            control.crearEcosistema(txtNombre.getText(), txtUbicacion.getText(),
                (NivelAfectacion) comboNivel.getSelectedItem());
            txtNombre.setText("");
            txtUbicacion.setText("");
            comboNivel.setSelectedIndex(0);
            refrescar();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos inválidos",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void asignar(){
        try {
            Ecosistema eco = (Ecosistema) comboEcosistema.getSelectedItem();
            Especie esp = (Especie) comboEspecie.getSelectedItem();
            control.asignarEspecieAEcosistema(esp, eco);
            int fila = tabla.getSelectedRow();
            refrescar();
            if (fila >= 0 && fila < tabla.getRowCount()) {
                tabla.setRowSelectionInterval(fila, fila);
            }
            JOptionPane.showMessageDialog(this, "Especie asignada al ecosistema.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo asignar",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void mostrarEspecies(){
        modeloLista.clear();
        int fila = tabla.getSelectedRow();
        if (fila < 0 || ecosistemas == null || fila >= ecosistemas.size()) {
            lblEspeciesDe.setText("Especies del ecosistema seleccionado");
            return;
        }
        Ecosistema eco = ecosistemas.get(fila);
        lblEspeciesDe.setText("Especies de: " + eco.getNombre());
        ArrayList<Especie> lista = eco.getEspecies();
        for (int i = 0; i < lista.size(); i++) {
            modeloLista.addElement(lista.get(i));
        }
    }

    public void refrescar(){
        ecosistemas = control.getEcosistemas();
        modeloTabla.setRowCount(0);
        for (int i = 0; i < ecosistemas.size(); i++) {
            Ecosistema e = ecosistemas.get(i);
            modeloTabla.addRow(new Object[]{e.getNombre(), e.getUbicacion(),
                e.getNivelAfectacion(), e.getEspecies().size()});
        }

        Object ecoSeleccionado = comboEcosistema.getSelectedItem();
        Object espSeleccionada = comboEspecie.getSelectedItem();

        comboEcosistema.removeAllItems();
        for (int i = 0; i < ecosistemas.size(); i++) {
            comboEcosistema.addItem(ecosistemas.get(i));
        }
        comboEspecie.removeAllItems();
        ArrayList<Especie> especies = control.getEspecies();
        for (int i = 0; i < especies.size(); i++) {
            comboEspecie.addItem(especies.get(i));
        }

        if (ecoSeleccionado != null) {
            comboEcosistema.setSelectedItem(ecoSeleccionado);
        }
        if (espSeleccionada != null) {
            comboEspecie.setSelectedItem(espSeleccionada);
        }
        mostrarEspecies();
    }
}
