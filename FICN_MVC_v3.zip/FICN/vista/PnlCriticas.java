package vista;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import controlador.Controlador;
import modelo.*;

public class PnlCriticas extends JPanel implements ActionListener
{
    private Controlador control;

    private JComboBox<Ecosistema> comboEcosistema;
    private JButton btnFiltrar;
    private DefaultTableModel modeloTabla;
    private JTable tabla;
    private JLabel lblResumen;
    private boolean filtrado;

    public PnlCriticas(Controlador control){
        this.control = control;
        crearInterfaz();
        refrescar();
    }

    private void crearInterfaz(){
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        comboEcosistema = new JComboBox<Ecosistema>();
        btnFiltrar = new JButton("Filtrar en peligro crítico");
        lblResumen = new JLabel(" ");

        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        filtro.setBorder(BorderFactory.createTitledBorder("Filtrar especies en Peligro Crítico"));
        filtro.add(new JLabel("Ecosistema:"));
        filtro.add(comboEcosistema);
        filtro.add(btnFiltrar);
        add(filtro, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new String[]{"Nombre común", "Nombre científico", "Clasificación",
            "Categoría UICN", "Factor de riesgo", "Población actual"}, 0)
        {
            public boolean isCellEditable(int fila, int columna){
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setRowHeight(22);

        JPanel centro = new JPanel(new BorderLayout());
        centro.setBorder(BorderFactory.createTitledBorder("Especies críticas del ecosistema"));
        centro.add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);
        add(lblResumen, BorderLayout.SOUTH);

        btnFiltrar.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){
        if (e.getSource() == btnFiltrar) {
            filtrar();
        }
    }

    private void filtrar(){
        modeloTabla.setRowCount(0);
        filtrado = false;
        try {
            Ecosistema eco = (Ecosistema) comboEcosistema.getSelectedItem();
            filtrado = true;
            ArrayList<Especie> criticas = control.filtrarCriticas(eco);
            for (int i = 0; i < criticas.size(); i++) {
                Especie s = criticas.get(i);
                modeloTabla.addRow(new Object[]{s.getNombreComun(), s.getNombreCientifico(), s.getClasificacion(),
                    s.getCategoriaUICN(), s.getFactorRiesgoPrincipal(), s.getPoblacionActual()});
            }
            if (criticas.isEmpty()) {
                lblResumen.setText("El ecosistema \"" + eco.getNombre() + "\" no tiene especies en Peligro Crítico.");
            } else {
                lblResumen.setText(criticas.size() + " especie(s) en Peligro Crítico en \"" + eco.getNombre() + "\".");
            }
        } catch (IllegalArgumentException ex) {
            lblResumen.setText(" ");
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Sin ecosistema",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    public void refrescar(){
        Object seleccionado = comboEcosistema.getSelectedItem();
        comboEcosistema.removeAllItems();
        ArrayList<Ecosistema> ecosistemas = control.getEcosistemas();
        for (int i = 0; i < ecosistemas.size(); i++) {
            comboEcosistema.addItem(ecosistemas.get(i));
        }
        if (seleccionado != null) {
            comboEcosistema.setSelectedItem(seleccionado);
        }
        modeloTabla.setRowCount(0);
        lblResumen.setText(" ");
        if (filtrado && comboEcosistema.getItemCount() > 0) {
            filtrar();
        }
    }
}
