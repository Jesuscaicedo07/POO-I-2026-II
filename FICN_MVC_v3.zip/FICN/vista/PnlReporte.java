package vista;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import controlador.Controlador;
import modelo.*;

public class PnlReporte extends JPanel implements ActionListener
{
    private Controlador control;
    private ReportePrioridad reporte;

    private JTextField txtPresupuesto;
    private JButton btnGenerar, btnExportar;
    private JLabel lblPrioritaria, lblAviso;
    private DefaultTableModel modeloTabla;
    private JTable tabla;

    public PnlReporte(Controlador control){
        this.control = control;
        crearInterfaz();
    }

    private void crearInterfaz(){
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtPresupuesto = new JTextField(14);
        btnGenerar = new JButton("Generar reporte");
        btnExportar = new JButton("Exportar a .txt");
        btnExportar.setEnabled(false);
        lblPrioritaria = new JLabel("-");
        lblPrioritaria.setFont(lblPrioritaria.getFont().deriveFont(Font.BOLD, 15f));
        lblAviso = new JLabel(" ");

        JPanel entrada = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        entrada.setBorder(BorderFactory.createTitledBorder("Presupuesto disponible"));
        entrada.add(new JLabel("Presupuesto (ej. 1500000):"));
        entrada.add(txtPresupuesto);
        entrada.add(btnGenerar);
        entrada.add(btnExportar);
        add(entrada, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new String[]{"Posición", "Especie", "Categoría UICN",
            "Población actual", "Variación (%)", "Declive anual (%)"}, 0)
        {
            public boolean isCellEditable(int fila, int columna){
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setRowHeight(22);

        JPanel prioritaria = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        prioritaria.add(new JLabel("Especie que se extingue más rápido:"));
        prioritaria.add(lblPrioritaria);

        JPanel centro = new JPanel(new BorderLayout(0, 4));
        centro.setBorder(BorderFactory.createTitledBorder("Ranking de urgencia"));
        centro.add(prioritaria, BorderLayout.NORTH);
        centro.add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);
        add(lblAviso, BorderLayout.SOUTH);

        btnGenerar.addActionListener(this);
        btnExportar.addActionListener(this);
        txtPresupuesto.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){
        Object origen = e.getSource();

        if (origen == btnGenerar || origen == txtPresupuesto) {
            generar();
        } else if (origen == btnExportar) {
            exportar();
        }
    }

    private void generar(){
        try {
            reporte = control.generarReportePrioridad(txtPresupuesto.getText());
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Presupuesto inválido",
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        mostrarReporte();
    }

    private void mostrarReporte(){
        modeloTabla.setRowCount(0);
        ArrayList<ItemRanking> ranking = reporte.getRankingUrgencia();
        for (int i = 0; i < ranking.size(); i++) {
            ItemRanking item = ranking.get(i);
            Especie s = item.getEspecie();
            modeloTabla.addRow(new Object[]{item.getPosicion(), s, s.getCategoriaUICN(), s.getPoblacionActual(),
                String.format("%+.2f", item.getVariacionPorcentual()),
                String.format("%.2f", item.getTasaDeclive())});
        }
        Especie prioritaria = reporte.getEspeciePrioritaria();
        if (prioritaria == null) {
            lblPrioritaria.setText("-");
        } else {
            lblPrioritaria.setText(prioritaria.toString());
        }
        lblAviso.setText(control.getAvisoReporte(reporte));
        btnExportar.setEnabled(prioritaria != null);
    }

    private void exportar(){
        if (reporte == null) {
            return;
        }
        JFileChooser selector = new JFileChooser();
        selector.setSelectedFile(new File("reporte_prioridad.txt"));
        if (selector.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        try {
            control.exportarReporte(reporte, selector.getSelectedFile());
            JOptionPane.showMessageDialog(this, "Reporte exportado correctamente.");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "No se pudo guardar el archivo: " + ex.getMessage(),
                "Error al exportar", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void refrescar(){
        // si ya había un reporte, lo recalculo con el mismo presupuesto
        if (reporte != null) {
            reporte = control.generarReportePrioridad(reporte.getPresupuestoDisponible());
            mostrarReporte();
        }
    }
}
