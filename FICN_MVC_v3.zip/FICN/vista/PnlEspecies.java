package vista;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import controlador.Controlador;
import modelo.*;

public class PnlEspecies extends JPanel implements ActionListener
{
    private Controlador control;
    private FrmPrincipal ventana;
    private ArrayList<Especie> visibles;

    private JTextField txtNombreComun, txtNombreCientifico, txtBuscar;
    private JComboBox<ClasificacionBiologica> comboClasificacion;
    private JComboBox<CategoriaUICN> comboCategoria;
    private JComboBox<FactorRiesgo> comboFactor;
    private JButton btnCrear, btnModificar, btnLimpiar, btnBuscar, btnTodas;
    private DefaultTableModel modeloTabla;
    private JTable tabla;

    public PnlEspecies(Controlador control, FrmPrincipal ventana){
        this.control = control;
        this.ventana = ventana;
        crearInterfaz();
        refrescar();
    }

    private void crearInterfaz(){
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtNombreComun = new JTextField(18);
        txtNombreCientifico = new JTextField(18);
        txtBuscar = new JTextField(20);
        comboClasificacion = new JComboBox<ClasificacionBiologica>(ClasificacionBiologica.values());
        comboCategoria = new JComboBox<CategoriaUICN>(CategoriaUICN.values());
        comboFactor = new JComboBox<FactorRiesgo>(FactorRiesgo.values());
        btnCrear = new JButton("Crear");
        btnModificar = new JButton("Modificar");
        btnLimpiar = new JButton("Limpiar");
        btnBuscar = new JButton("Buscar");
        btnTodas = new JButton("Mostrar todas");

        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBorder(BorderFactory.createTitledBorder("Datos de la especie"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);
        g.anchor = GridBagConstraints.WEST;
        g.fill = GridBagConstraints.HORIZONTAL;

        agregarCampo(formulario, g, 0, 0, "Nombre común:", txtNombreComun);
        agregarCampo(formulario, g, 0, 2, "Nombre científico:", txtNombreCientifico);
        agregarCampo(formulario, g, 1, 0, "Clasificación:", comboClasificacion);
        agregarCampo(formulario, g, 1, 2, "Categoría UICN:", comboCategoria);
        agregarCampo(formulario, g, 2, 0, "Factor de riesgo:", comboFactor);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        botones.add(btnCrear);
        botones.add(btnModificar);
        botones.add(btnLimpiar);
        g.gridx = 2;
        g.gridy = 2;
        g.gridwidth = 2;
        formulario.add(botones, g);

        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 4));
        busqueda.setBorder(BorderFactory.createTitledBorder("Buscar especies"));
        busqueda.add(new JLabel("Nombre, clasificación o categoría:"));
        busqueda.add(txtBuscar);
        busqueda.add(btnBuscar);
        busqueda.add(btnTodas);

        JPanel norte = new JPanel(new BorderLayout(0, 8));
        norte.add(formulario, BorderLayout.NORTH);
        norte.add(busqueda, BorderLayout.SOUTH);
        add(norte, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new String[]{"Nombre común", "Nombre científico", "Clasificación",
            "Categoría UICN", "Factor de riesgo", "Población actual"}, 0)
        {
            public boolean isCellEditable(int fila, int columna){
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(22);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        btnCrear.addActionListener(this);
        btnModificar.addActionListener(this);
        btnLimpiar.addActionListener(this);
        btnBuscar.addActionListener(this);
        btnTodas.addActionListener(this);
        txtBuscar.addActionListener(this);
        tabla.getSelectionModel().addListSelectionListener(new ListSelectionListener()
        {
            public void valueChanged(ListSelectionEvent e){
                if (!e.getValueIsAdjusting()) {
                    cargarSeleccion();
                }
            }
        });
    }

    private void agregarCampo(JPanel panel, GridBagConstraints g, int fila, int columna, String texto, Component campo){
        g.gridwidth = 1;
        g.gridy = fila;
        g.gridx = columna;
        g.weightx = 0;
        panel.add(new JLabel(texto), g);
        g.gridx = columna + 1;
        g.weightx = 1;
        panel.add(campo, g);
    }

    public void actionPerformed(ActionEvent e){
        Object origen = e.getSource();

        if (origen == btnCrear) {
            crear();
        } else if (origen == btnModificar) {
            modificar();
        } else if (origen == btnLimpiar) {
            limpiar();
        } else if (origen == btnBuscar || origen == txtBuscar) {
            mostrar(control.buscarEspecie(txtBuscar.getText()));
        } else if (origen == btnTodas) {
            txtBuscar.setText("");
            refrescar();
        }
    }

    private void crear(){
        try {
            control.crearEspecie(txtNombreComun.getText(), txtNombreCientifico.getText(),
                (ClasificacionBiologica) comboClasificacion.getSelectedItem(),
                (CategoriaUICN) comboCategoria.getSelectedItem(),
                (FactorRiesgo) comboFactor.getSelectedItem());
            limpiar();
            refrescar();
            ventana.especiesCambiaron();
            JOptionPane.showMessageDialog(this, "Especie creada correctamente.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos inválidos",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void modificar(){
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Seleccione una especie de la tabla para modificarla.",
                "Sin selección", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        Especie especie = visibles.get(fila);

        try {
            control.modificarEspecie(especie, txtNombreComun.getText(), txtNombreCientifico.getText(),
                (ClasificacionBiologica) comboClasificacion.getSelectedItem(),
                (CategoriaUICN) comboCategoria.getSelectedItem(),
                (FactorRiesgo) comboFactor.getSelectedItem());
            refrescar();
            ventana.especiesCambiaron();
            JOptionPane.showMessageDialog(this, "Especie modificada correctamente.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos inválidos",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void cargarSeleccion(){
        int fila = tabla.getSelectedRow();
        if (fila < 0 || visibles == null || fila >= visibles.size()) {
            return;
        }
        Especie e = visibles.get(fila);
        txtNombreComun.setText(e.getNombreComun());
        txtNombreCientifico.setText(e.getNombreCientifico());
        comboClasificacion.setSelectedItem(e.getClasificacion());
        comboCategoria.setSelectedItem(e.getCategoriaUICN());
        comboFactor.setSelectedItem(e.getFactorRiesgoPrincipal());
    }

    private void limpiar(){
        txtNombreComun.setText("");
        txtNombreCientifico.setText("");
        comboClasificacion.setSelectedIndex(0);
        comboCategoria.setSelectedIndex(0);
        comboFactor.setSelectedIndex(0);
        tabla.clearSelection();
    }

    private void mostrar(ArrayList<Especie> lista){
        visibles = lista;
        modeloTabla.setRowCount(0);
        for (int i = 0; i < lista.size(); i++) {
            Especie e = lista.get(i);
            modeloTabla.addRow(new Object[]{e.getNombreComun(), e.getNombreCientifico(), e.getClasificacion(),
                e.getCategoriaUICN(), e.getFactorRiesgoPrincipal(), e.getPoblacionActual()});
        }
    }

    public void refrescar(){
        mostrar(control.getEspecies());
    }
}
