package vista;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import controlador.Controlador;
import modelo.*;

public class PnlAmenazas extends JPanel implements ActionListener
{
    private static final String SIN_ESPECIE = "(Ecosistema en general)";

    private Controlador control;
    private ArrayList<Amenaza> visibles;

    private JComboBox<Ecosistema> comboEcosistema;
    private JComboBox<Object> comboEspecie;
    private JComboBox<FactorRiesgo> comboFactor;
    private JTextField txtDescripcion, txtFecha, txtInvestigador;
    private JButton btnRegistrar, btnMarcarGrave;
    private DefaultTableModel modeloTabla;
    private JTable tabla;
    private JLabel lblResumen;

    public PnlAmenazas(Controlador control){
        this.control = control;
        crearInterfaz();
        refrescar();
    }

    private void crearInterfaz(){
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        comboEcosistema = new JComboBox<Ecosistema>();
        comboEspecie = new JComboBox<Object>();
        comboFactor = new JComboBox<FactorRiesgo>(FactorRiesgo.values());
        txtDescripcion = new JTextField(20);
        txtFecha = new JTextField(10);
        txtInvestigador = new JTextField(16);
        btnRegistrar = new JButton("Registrar amenaza");
        btnMarcarGrave = new JButton("Marcar como grave");
        lblResumen = new JLabel(" ");

        txtFecha.setText(control.fechaActual());

        JPanel formulario = new JPanel(new GridBagLayout());
        formulario.setBorder(BorderFactory.createTitledBorder("Registrar amenaza observada"));
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 6, 4, 6);
        g.anchor = GridBagConstraints.WEST;
        g.fill = GridBagConstraints.HORIZONTAL;

        agregarCampo(formulario, g, 0, 0, "Ecosistema:", comboEcosistema);
        agregarCampo(formulario, g, 0, 2, "Especie afectada:", comboEspecie);
        agregarCampo(formulario, g, 1, 0, "Descripción:", txtDescripcion);
        agregarCampo(formulario, g, 1, 2, "Factor de riesgo:", comboFactor);
        agregarCampo(formulario, g, 2, 0, "Fecha (aaaa-mm-dd):", txtFecha);
        agregarCampo(formulario, g, 2, 2, "Investigador:", txtInvestigador);

        g.gridx = 3;
        g.gridy = 3;
        g.gridwidth = 1;
        g.fill = GridBagConstraints.NONE;
        g.anchor = GridBagConstraints.EAST;
        formulario.add(btnRegistrar, g);
        add(formulario, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new String[]{"Descripción", "Factor", "Fecha", "Investigador",
            "Especie afectada", "Grave"}, 0)
        {
            public boolean isCellEditable(int fila, int columna){
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(22);

        JPanel centro = new JPanel(new BorderLayout());
        centro.setBorder(BorderFactory.createTitledBorder("Amenazas del ecosistema seleccionado"));
        centro.add(new JScrollPane(tabla), BorderLayout.CENTER);
        add(centro, BorderLayout.CENTER);

        JPanel sur = new JPanel(new BorderLayout());
        sur.add(lblResumen, BorderLayout.CENTER);
        sur.add(btnMarcarGrave, BorderLayout.EAST);
        add(sur, BorderLayout.SOUTH);

        btnRegistrar.addActionListener(this);
        btnMarcarGrave.addActionListener(this);
        comboEcosistema.addActionListener(this);
    }

    private void agregarCampo(JPanel panel, GridBagConstraints g, int fila, int columna, String texto, Component campo){
        g.gridwidth = 1;
        g.gridy = fila;
        g.gridx = columna;
        g.weightx = 0;
        panel.add(new JLabel(texto), g);
        g.gridx = columna + 1;
        g.weightx = 1;
        panel.add(campo, g);
    }

    public void actionPerformed(ActionEvent e){
        Object origen = e.getSource();

        if (origen == btnRegistrar) {
            registrar();
        } else if (origen == btnMarcarGrave) {
            marcarGrave();
        } else if (origen == comboEcosistema) {
            cargarEspecies();
            mostrarAmenazas();
        }
    }

    private void registrar(){
        try {
            Ecosistema eco = (Ecosistema) comboEcosistema.getSelectedItem();
            Object seleccion = comboEspecie.getSelectedItem();
            Especie afectada = null;
            if (seleccion instanceof Especie) {
                afectada = (Especie) seleccion;
            }
            control.registrarAmenaza(eco, txtDescripcion.getText(), (FactorRiesgo) comboFactor.getSelectedItem(),
                txtFecha.getText(), txtInvestigador.getText(), afectada);
            txtDescripcion.setText("");
            txtInvestigador.setText("");
            comboFactor.setSelectedIndex(0);
            mostrarAmenazas();
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Datos inválidos",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void marcarGrave(){
        int fila = tabla.getSelectedRow();
        if (fila < 0 || visibles == null || fila >= visibles.size()) {
            JOptionPane.showMessageDialog(this, "Seleccione una amenaza de la tabla para marcarla como grave.",
                "Sin selección", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        Amenaza a = visibles.get(fila);
        if (a.esGrave()) {
            JOptionPane.showMessageDialog(this, "Esa amenaza ya está marcada como grave.",
                "Amenaza grave", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        try {
            control.marcarAmenazaGrave(a);
            mostrarAmenazas();
            if (fila < tabla.getRowCount()) {
                tabla.setRowSelectionInterval(fila, fila);
            }
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo marcar",
                JOptionPane.WARNING_MESSAGE);
        }
    }

    private void cargarEspecies(){
        comboEspecie.removeAllItems();
        comboEspecie.addItem(SIN_ESPECIE);
        Ecosistema eco = (Ecosistema) comboEcosistema.getSelectedItem();
        if (eco != null) {
            ArrayList<Especie> lista = eco.getEspecies();
            for (int i = 0; i < lista.size(); i++) {
                comboEspecie.addItem(lista.get(i));
            }
        }
    }

    private void mostrarAmenazas(){
        modeloTabla.setRowCount(0);
        visibles = null;
        Ecosistema eco = (Ecosistema) comboEcosistema.getSelectedItem();
        if (eco == null) {
            lblResumen.setText("Cree un ecosistema para registrar amenazas.");
            return;
        }
        visibles = eco.getAmenazas();
        for (int i = 0; i < visibles.size(); i++) {
            Amenaza a = visibles.get(i);
            String especie = SIN_ESPECIE;
            if (a.getEspecieAfectada() != null) {
                especie = a.getEspecieAfectada().getNombreComun();
            }
            String grave = "No";
            if (a.esGrave()) {
                grave = "Sí";
            }
            modeloTabla.addRow(new Object[]{a.getDescripcion(), a.getFactor(),
                control.formatearFecha(a.getFechaObservacion()), a.getInvestigador(), especie, grave});
        }
        lblResumen.setText(visibles.size() + " amenaza(s) registradas, " + eco.getAmenazasGraves().size()
            + " grave(s).");
    }

    public void refrescar(){
        Object seleccionado = comboEcosistema.getSelectedItem();
        comboEcosistema.removeActionListener(this);
        comboEcosistema.removeAllItems();
        ArrayList<Ecosistema> ecosistemas = control.getEcosistemas();
        for (int i = 0; i < ecosistemas.size(); i++) {
            comboEcosistema.addItem(ecosistemas.get(i));
        }
        if (seleccionado != null) {
            comboEcosistema.setSelectedItem(seleccionado);
        }
        comboEcosistema.addActionListener(this);

        Object especieSel = comboEspecie.getSelectedItem();
        cargarEspecies();
        if (especieSel != null) {
            comboEspecie.setSelectedItem(especieSel);
        }
        mostrarAmenazas();
    }
}
