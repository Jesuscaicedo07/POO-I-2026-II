import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import controlador.Controlador;
import vista.FrmPrincipal;

public class Main
{
    public static void main(String[] args){
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run(){
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception ex) {
                    System.out.println("Se usa el aspecto por defecto");
                }
                Controlador control = new Controlador();
                control.cargarDatosEjemplo();
                new FrmPrincipal(control).setVisible(true);
            }
        });
    }
}
