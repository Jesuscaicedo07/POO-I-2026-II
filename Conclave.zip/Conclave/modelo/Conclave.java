package modelo;


/**
 * Write a description of class Conclave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Conclave
{
    private Cardenal cardenal;
    
}