package modelo;
import javax.swing.*;

/**
 * Write a description of class Cardenales here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Cardenal
{
    private TipoCardenal tipoCardenal;
    private Pais pais;
    private int edad;
    private boolean enfermo=false;
    
    public Cardenal(){}
    
    public Cardenal(TipoCardenal tipoCardenal,Pais pais, int edad){
        this.tipoCardenal=tipoCardenal;
        this.pais=pais;
        this.edad=edad;
    }

//Start GetterSetterExtension Source Code

    /**GET Method Propertie tipoCardenal*/
    public TipoCardenal getTipoCardenal(){
        return this.tipoCardenal;
    }//end method getTipoCardenal

    /**SET Method Propertie tipoCardenal*/
    public void setTipoCardenal(TipoCardenal tipoCardenal){
        this.tipoCardenal = tipoCardenal;
    }//end method setTipoCardenal

    /**GET Method Propertie pais*/
    public Pais getPais(){
        return this.pais;
    }//end method getPais

    /**SET Method Propertie pais*/
    public void setPais(Pais pais){
        this.pais = pais;
    }//end method setPais

    /**GET Method Propertie edad*/
    public int getEdad(){
        return this.edad;
    }//end method getEdad

    /**SET Method Propertie edad*/
    public void setEdad(int edad){
        this.edad = edad;
    }//end method setEdad

//End GetterSetterExtension Source Code
   public void rectificarEdad(int edad){
       if (edad>=80){
           JOptionPane.showMessageDialog(null,"No puede votar");
       }
   }

}//End class