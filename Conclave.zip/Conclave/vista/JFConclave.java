package vista;
import javax.swing.*;
import java.awt.*;

/**
 * Write a description of class JFConclave here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class JFConclave extends JFrame
{
    JLabel lblLista, lblRonda; 
    JButton btnVotar, btnMostrar, btnSiguiente;
    JComboBox <String> cmbLista;
    JTextArea txtEsp;
    JTextField txtRonda;
    
    public JFConclave (){
        setTitle ("Votaciones conclave");
        setSize (400,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        
        String[] listado = {"Juan", "Pedro", "Francisco", "Daniel", "Pablo", "Jean", "Jacobo", "Jose", "Felipe", "Carlos", "Andres", "Santiago"};
        
        JPanel listados1 = new JPanel (new GridLayout (2,2,5,5));
        
        JPanel lista = new JPanel (new GridLayout (1,2,5,5));
        
        JPanel lista1 = new JPanel (new GridLayout (1,1,5,5));
        lblLista = new JLabel ("Lista de Cardenales");
        
        JPanel lista2 = new JPanel (new GridLayout (1,1,5,5));
        cmbLista = new JComboBox <>(listado); 
        
        JPanel botones = new JPanel(new GridLayout (1,2,5,5));
        
        JPanel boton1 = new JPanel(new GridLayout (1,1,5,5));
        boton1.setLayout(new BoxLayout(boton1,BoxLayout.X_AXIS));
        JButton btnVotar = new JButton("Votar");
        
        JPanel ronda = new JPanel(new GridLayout (1,2,5,5));
        
        JPanel ronda1= new JPanel (new GridLayout (1,1,5,5));
        lblRonda = new JLabel ("Ronda Num");
        
        JPanel ronda2= new JPanel (new GridLayout (1,1,5,5));
        txtRonda = new JTextField ("1");
        
        JPanel listados2 = new JPanel (new GridLayout (2,1,5,5));
         
        JPanel mostrar = new JPanel (new BorderLayout());
        txtEsp= new JTextArea ();
        
        JPanel botones22 = new JPanel(new GridLayout (1,2,5,5));
        boton1.setLayout(new BoxLayout(boton1,BoxLayout.X_AXIS));
        JButton btnMostrar = new JButton("Mostrar Resultados");
        JButton btnSiguiente = new JButton("Siguiente Ronda");
        
        lista.add(lista1);
        lista.add(lista2);
        botones.add(boton1);
        botones.add(ronda);
        lista1.add(lblLista, BorderLayout.WEST);
        lista2.add(cmbLista, BorderLayout.EAST);
        boton1.add(btnVotar, BorderLayout.CENTER);
        ronda.add(ronda1);
        ronda.add(ronda2);
        ronda1.add(lblRonda,BorderLayout.WEST); 
        ronda2.add(txtRonda,BorderLayout.EAST); 
        mostrar.add(txtEsp);
        botones22.add(btnMostrar);
        botones22.add(btnSiguiente);
        listados1.add(lista, BorderLayout.NORTH);
        listados1.add(botones, BorderLayout.SOUTH);
        
        listados2.add(botones22, BorderLayout.SOUTH);
        add(listados1, BorderLayout.NORTH);
        add(mostrar,BorderLayout.CENTER);
        add(listados2, BorderLayout.SOUTH);
        setVisible (true);
    }
}